import express from 'express';
import type { NextFunction, Request, Response } from 'express';
import { spawn } from 'child_process';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

const __filename = fileURLToPath(import.meta.url);
const PROJECT_ROOT = path.dirname(__filename);

const envFilePath = path.resolve(PROJECT_ROOT, '.env');
if (fs.existsSync(envFilePath)) {
  dotenv.config({ path: envFilePath, override: true });
} else {
  dotenv.config();
}

const app = express();

// Use process.env.PORT || 3000 while guarding against internal preview NGINX_PORT collisions
const resolvePort = (): number => {
  const rawPort = process.env.PORT ? parseInt(process.env.PORT, 10) : NaN;
  const nginxPort = process.env.NGINX_PORT ? parseInt(process.env.NGINX_PORT, 10) : NaN;
  const defaultPort = process.env.DEFAULT_APP_PORT ? parseInt(process.env.DEFAULT_APP_PORT, 10) : 3000;

  if (!Number.isNaN(rawPort) && rawPort > 0) {
    if (!Number.isNaN(nginxPort) && rawPort === nginxPort) {
      return !Number.isNaN(defaultPort) && defaultPort > 0 ? defaultPort : 3000;
    }
    return rawPort;
  }
  return !Number.isNaN(defaultPort) && defaultPort > 0 ? defaultPort : 3000;
};

const PORT = resolvePort();

function getPythonExecutable(): string {
  const venvPython = path.resolve(PROJECT_ROOT, '.venv/bin/python3');
  if (fs.existsSync(venvPython)) {
    return venvPython;
  }
  return 'python3';
}

app.use(express.json());

// Helper to resolve model artifact (.joblib primary, .pkl fallback)
function getModelPaths() {
  const joblibPath = path.resolve(PROJECT_ROOT, 'ml/saved_models/random_forest_phishing.joblib');
  const pklPath = path.resolve(PROJECT_ROOT, 'ml/saved_models/random_forest_phishing.pkl');
  const infoPath = path.resolve(PROJECT_ROOT, 'ml/saved_models/model_info.json');

  const modelPath = fs.existsSync(joblibPath)
    ? joblibPath
    : fs.existsSync(pklPath)
    ? pklPath
    : joblibPath;

  return { modelPath, infoPath, modelExists: fs.existsSync(modelPath) };
}

// Track background ML environment verification promise so routes never race cold start
let mlSetupPromise: Promise<boolean> | null = null;
let mlReadyState: boolean | null = null;

// In-memory training job state
interface TrainingJob {
  status: 'idle' | 'running' | 'completed' | 'error';
  logs: string[];
  startTime: number | null;
  endTime: number | null;
  error: string | null;
  pid?: number;
}

const activeJob: TrainingJob = {
  status: 'idle',
  logs: [],
  startTime: null,
  endTime: null,
  error: null
};

// Log helper
function appendLog(msg: string) {
  const line = msg.trimEnd();
  if (line) {
    activeJob.logs.push(line);
    // Keep last 1500 log lines
    if (activeJob.logs.length > 1500) {
      activeJob.logs.shift();
    }
  }
}

// 0. Health check
app.get('/api/health', (_req: Request, res: Response) => {
  const { modelExists } = getModelPaths();
  res.json({
    status: 'ok',
    mlReady: mlReadyState,
    modelExists
  });
});

// 1. Backend Runtime Info
app.get('/api/backend-info', async (_req: Request, res: Response) => {
  const { modelPath, infoPath, modelExists } = getModelPaths();

  let modelInfo = null;
  if (fs.existsSync(infoPath)) {
    try {
      modelInfo = JSON.parse(fs.readFileSync(infoPath, 'utf-8'));
    } catch {
      // ignore parse error
    }
  }

  // Probe Python, Scikit-learn, joblib, and verify model load if artifact exists
  const probeScript = [
    'import json, platform',
    'out = {"py": platform.python_version(), "sklearn": None, "loadable": False, "err": None}',
    'try:',
    '    import sklearn, joblib, numpy, pandas, supabase',
    '    out["sklearn"] = sklearn.__version__',
    `    import os; mp = ${JSON.stringify(modelPath)}`,
    '    if os.path.exists(mp):',
    '        obj = joblib.load(mp)',
    '        m = obj["model"] if isinstance(obj, dict) and "model" in obj else obj',
    '        out["loadable"] = hasattr(m, "predict")',
    'except Exception as e:',
    '    out["err"] = str(e)',
    'print(json.dumps(out))'
  ].join('\n');

  const pythonCheck = spawn(getPythonExecutable(), ['-c', probeScript], { cwd: PROJECT_ROOT, env: process.env });

  let stdoutData = '';
  let pythonStderr = '';
  pythonCheck.stdout.on('data', (d) => {
    stdoutData += d.toString();
  });
  pythonCheck.stderr.on('data', (d) => {
    pythonStderr += d.toString().trim();
  });

  pythonCheck.on('error', (err) => {
    const hasUrl = !!process.env.SUPABASE_URL;
    const hasKey = !!(
      process.env.SUPABASE_KEY ||
      process.env.SUPABASE_SERVICE_ROLE_KEY ||
      process.env.SUPABASE_SECRET_KEY ||
      process.env.SUPABASE_ANON_KEY
    );
    const tableName = process.env.SUPABASE_TABLE_NAME || 'phishing_dataset';

    res.json({
      runtime: 'Linux Node.js + Python',
      pythonAvailable: false,
      scikitLearnVersion: err.message,
      scikitLearnSupported: false,
      mlEngine: 'Scikit-learn RandomForestClassifier (Native Python)',
      database: 'Supabase (PostgreSQL)',
      supabaseConfigured: hasUrl && hasKey,
      supabaseTable: tableName,
      modelTrained: modelExists,
      modelInfo
    });
  });

  pythonCheck.on('close', (code) => {
    let parsed: { py?: string; sklearn?: string | null; loadable?: boolean; err?: string | null } = {};
    try {
      parsed = JSON.parse(stdoutData.trim());
    } catch {
      // ignore parse failure
    }

    const isPythonReady = code === 0 && !!parsed.sklearn;
    const hasUrl = !!process.env.SUPABASE_URL;
    const hasKey = !!(
      process.env.SUPABASE_KEY ||
      process.env.SUPABASE_SERVICE_ROLE_KEY ||
      process.env.SUPABASE_SECRET_KEY ||
      process.env.SUPABASE_ANON_KEY
    );
    const tableName = process.env.SUPABASE_TABLE_NAME || 'phishing_dataset';
    const modelTrained = modelExists && (isPythonReady ? Boolean(parsed.loadable) : true);

    res.json({
      runtime: `Linux Node.js + Python ${parsed.py || '3'}`,
      pythonAvailable: isPythonReady,
      scikitLearnVersion: isPythonReady
        ? parsed.sklearn
        : parsed.err || pythonStderr || 'Not detected',
      scikitLearnSupported: isPythonReady,
      mlEngine: 'Scikit-learn RandomForestClassifier (Native Python)',
      database: 'Supabase (PostgreSQL)',
      supabaseConfigured: hasUrl && hasKey,
      supabaseTable: tableName,
      modelTrained,
      modelInfo
    });
  });
});

// 2. Supabase Connection Test
app.get('/api/supabase/status', async (_req: Request, res: Response) => {
  if (mlSetupPromise) {
    await mlSetupPromise;
  }

  const py = spawn(
    getPythonExecutable(),
    [
      '-c',
      'import json; from ml.supabase_client import test_connection; print(json.dumps(test_connection()))'
    ],
    { cwd: PROJECT_ROOT, env: process.env }
  );

  let stdoutData = '';
  let stderrData = '';

  py.stdout.on('data', (data) => {
    stdoutData += data.toString();
  });

  py.stderr.on('data', (data) => {
    stderrData += data.toString();
  });

  py.on('error', (err) => {
    res.status(500).json({
      connected: false,
      error: `Failed to spawn Python runtime: ${err.message}`
    });
  });

  py.on('close', (code) => {
    if (code !== 0) {
      return res.status(500).json({
        connected: false,
        error: (stderrData || stdoutData || 'Failed to execute Supabase connection check.').trim()
      });
    }
    try {
      const firstBrace = stdoutData.indexOf('{');
      const lastBrace = stdoutData.lastIndexOf('}');
      if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
        const jsonSlice = stdoutData.slice(firstBrace, lastBrace + 1);
        const result = JSON.parse(jsonSlice);
        return res.json(result);
      }
      const result = JSON.parse(stdoutData.trim());
      res.json(result);
    } catch {
      res.status(500).json({
        connected: false,
        error: stdoutData || stderrData || 'Invalid response from connection test.'
      });
    }
  });
});

// 3. Save Supabase Config to Server .env
app.post('/api/supabase/configure', (req: Request, res: Response) => {
  const { supabaseUrl, supabaseKey, tableName } = req.body || {};

  if (!supabaseUrl || !supabaseKey) {
    return res.status(400).json({ error: 'supabaseUrl and supabaseKey are required' });
  }

  let cleanUrl = String(supabaseUrl).trim().replace(/\/+$/, '');
  if (cleanUrl.includes('/rest/v1')) {
    cleanUrl = cleanUrl.split('/rest/v1')[0].replace(/\/+$/, '');
  }
  const cleanKey = String(supabaseKey).trim();
  const cleanTable = tableName ? String(tableName).trim() : 'phishing_dataset';

  process.env.SUPABASE_URL = cleanUrl;
  process.env.SUPABASE_KEY = cleanKey;
  if (cleanKey.startsWith('sb_secret_') || cleanKey.toLowerCase().includes('service')) {
    process.env.SUPABASE_SERVICE_ROLE_KEY = cleanKey;
  } else {
    delete process.env.SUPABASE_SERVICE_ROLE_KEY;
  }
  process.env.SUPABASE_TABLE_NAME = cleanTable;

  // Persist to .env file
  const envPath = path.resolve(PROJECT_ROOT, '.env');
  let currentEnv = '';
  if (fs.existsSync(envPath)) {
    currentEnv = fs.readFileSync(envPath, 'utf-8');
  }

  const lines = currentEnv
    .split('\n')
    .filter(
      (l) =>
        !l.startsWith('SUPABASE_URL=') &&
        !l.startsWith('SUPABASE_KEY=') &&
        !l.startsWith('SUPABASE_SERVICE_ROLE_KEY=') &&
        !l.startsWith('SUPABASE_TABLE_NAME=')
    );

  lines.push(`SUPABASE_URL="${cleanUrl}"`);
  lines.push(`SUPABASE_KEY="${cleanKey}"`);
  if (cleanKey.startsWith('sb_secret_') || cleanKey.toLowerCase().includes('service')) {
    lines.push(`SUPABASE_SERVICE_ROLE_KEY="${cleanKey}"`);
  }
  lines.push(`SUPABASE_TABLE_NAME="${cleanTable}"`);

  fs.writeFileSync(envPath, lines.join('\n'), 'utf-8');

  res.json({
    success: true,
    message: 'Supabase credentials securely updated on backend server.'
  });
});

// 4. Trigger Training Pipeline
app.post('/api/train', async (req: Request, res: Response) => {
  if (activeJob.status === 'running') {
    return res.status(409).json({ error: 'Training is already in progress' });
  }

  if (mlSetupPromise) {
    await mlSetupPromise;
  }

  const body = req.body || {};
  const batchSize = body.batchSize ? parseInt(body.batchSize, 10) : 1000;
  const maxRecords = body.maxRecords ? parseInt(body.maxRecords, 10) : undefined;
  const testSize = body.testSize ? parseFloat(body.testSize) : 0.2;
  const nEstimators = body.nEstimators ? parseInt(body.nEstimators, 10) : 100;
  const maxDepth = body.maxDepth ? parseInt(body.maxDepth, 10) : 25;

  activeJob.status = 'running';
  activeJob.logs = [
    `[${new Date().toISOString()}] Initializing Scikit-learn Random Forest training pipeline...`,
    `[Config] Batch Size: ${batchSize} | Max Records: ${maxRecords ? maxRecords.toLocaleString() : 'All (Full Dataset)'} | Test Split: ${testSize * 100}% | Trees: ${nEstimators} | Depth: ${maxDepth}`
  ];
  activeJob.startTime = Date.now();
  activeJob.endTime = null;
  activeJob.error = null;

  const trainScriptPath = path.resolve(PROJECT_ROOT, 'ml/train.py');
  const args = [
    trainScriptPath,
    '--batch-size',
    String(batchSize),
    '--test-size',
    String(testSize),
    '--n-estimators',
    String(nEstimators),
    '--max-depth',
    String(maxDepth)
  ];

  if (maxRecords && maxRecords > 0) {
    args.push('--max-records', String(maxRecords));
  }

  const child = spawn(getPythonExecutable(), args, { cwd: PROJECT_ROOT, env: process.env });
  activeJob.pid = child.pid;

  child.stdout.on('data', (chunk) => {
    const text = chunk.toString();
    const lines = text.split('\n');
    for (const l of lines) {
      if (l.trim()) appendLog(l);
    }
  });

  child.stderr.on('data', (chunk) => {
    const text = chunk.toString();
    const lines = text.split('\n');
    for (const l of lines) {
      if (l.trim()) appendLog(`[WARN/ERR] ${l}`);
    }
  });

  child.on('error', (err) => {
    activeJob.endTime = Date.now();
    activeJob.status = 'error';
    activeJob.error = `Failed to start training process: ${err.message}`;
    appendLog(`[${new Date().toISOString()}] ERROR: ${activeJob.error}`);
  });

  child.on('close', (code) => {
    activeJob.endTime = Date.now();
    if (code === 0) {
      activeJob.status = 'completed';
      appendLog(`[${new Date().toISOString()}] SUCCESS: Pipeline finished. Model saved.`);
    } else {
      activeJob.status = 'error';
      activeJob.error = `Training process exited with code ${code}`;
      appendLog(`[${new Date().toISOString()}] ERROR: Process exited with exit code ${code}`);
    }
  });

  res.json({
    success: true,
    message: 'Training pipeline started',
    job: {
      status: activeJob.status,
      startTime: activeJob.startTime
    }
  });
});

// 5. Training Status & Logs Polling
app.get('/api/train/status', (_req: Request, res: Response) => {
  res.json(activeJob);
});

// 6. Evaluation Metrics & Confusion Matrix
app.get('/api/metrics', (_req: Request, res: Response) => {
  const { infoPath, modelExists } = getModelPaths();
  if (!fs.existsSync(infoPath)) {
    return res.json({
      trained: modelExists,
      message: modelExists
        ? 'Model artifact found, waiting for evaluation metadata.'
        : 'No model has been trained yet. Please configure Supabase and run training to compute real metrics.'
    });
  }

  try {
    const raw = fs.readFileSync(infoPath, 'utf-8');
    const data = JSON.parse(raw);
    res.json({
      trained: true,
      ...data
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read model info: ' + err.message });
  }
});

// 7. Live URL Predict
app.post('/api/predict', async (req: Request, res: Response) => {
  const { url } = req.body || {};
  if (!url || typeof url !== 'string' || !url.trim()) {
    return res.status(400).json({ error: 'Valid URL is required' });
  }

  if (mlSetupPromise) {
    await mlSetupPromise;
  }

  const { modelPath, modelExists } = getModelPaths();
  if (!modelExists) {
    return res.status(400).json({
      error: 'Model not trained yet. Please train the model on the Supabase dataset before running predictions.'
    });
  }

  const predictScriptPath = path.resolve(PROJECT_ROOT, 'ml/predict.py');
  const child = spawn(
    getPythonExecutable(),
    [predictScriptPath, url.trim(), '--model-path', modelPath, '--json'],
    { cwd: PROJECT_ROOT, env: process.env }
  );

  let stdoutData = '';
  let stderrData = '';
  let responded = false;

  child.stdout.on('data', (d) => {
    stdoutData += d.toString();
  });
  child.stderr.on('data', (d) => {
    stderrData += d.toString();
  });

  child.on('error', (err) => {
    if (responded) return;
    responded = true;
    res.status(500).json({
      error: `Failed to execute ML inference process: ${err.message}`
    });
  });

  child.on('close', (code) => {
    if (responded) return;
    responded = true;

    if (code !== 0) {
      const errorMsg = (stderrData || stdoutData || `Inference script failed with exit code ${code}`).trim();
      return res.status(500).json({
        error: errorMsg
      });
    }

    try {
      const parsed = JSON.parse(stdoutData.trim());
      res.json(parsed);
    } catch {
      res.status(500).json({
        error: 'Failed to parse prediction result: ' + (stdoutData || stderrData)
      });
    }
  });
});

// 8. Extract features directly for testing/inspection
app.post('/api/extract-features', async (req: Request, res: Response) => {
  const { url } = req.body || {};
  if (!url || typeof url !== 'string') {
    return res.status(400).json({ error: 'URL is required' });
  }

  if (mlSetupPromise) {
    await mlSetupPromise;
  }

  const child = spawn(
    getPythonExecutable(),
    [
      '-c',
      'import json, sys; from ml.feature_extractor import extract_features; print(json.dumps(extract_features(sys.argv[1])))',
      url.trim()
    ],
    { cwd: PROJECT_ROOT, env: process.env }
  );

  let stdoutData = '';
  let stderrData = '';

  child.stdout.on('data', (d) => {
    stdoutData += d.toString();
  });
  child.stderr.on('data', (d) => {
    stderrData += d.toString();
  });

  child.on('error', (err) => {
    res.status(500).json({
      error: `Failed to run feature extractor: ${err.message}`
    });
  });

  child.on('close', (code) => {
    if (code !== 0) {
      return res.status(500).json({
        error: stderrData || 'Feature extraction script failed.'
      });
    }
    try {
      const parsed = JSON.parse(stdoutData.trim());
      res.json(parsed);
    } catch {
      res.status(500).json({ error: 'Failed to parse features: ' + stdoutData });
    }
  });
});

// Ensure unknown /api/* routes return JSON instead of SPA HTML
app.use('/api', (_req: Request, res: Response) => {
  res.status(404).json({ error: 'API endpoint not found' });
});

// Global JSON error handler for API requests
app.use((err: any, req: Request, res: Response, next: NextFunction) => {
  if (req.path.startsWith('/api')) {
    const status = err.status || err.statusCode || 500;
    return res.status(status).json({
      error: err.message || 'Internal server error'
    });
  }
  next(err);
});

// Ensure Python ML environment and verify Random Forest model artifact without ever crashing Node.js
async function verifyModelArtifact(): Promise<boolean> {
  const { modelPath, modelExists } = getModelPaths();
  if (!modelExists) {
    console.warn(`[ML Startup] Notice: Model artifact does not exist yet at ${modelPath}`);
  }

  return new Promise((resolve) => {
    let settled = false;
    const finish = (ok: boolean) => {
      if (settled) return;
      settled = true;
      mlReadyState = ok;
      resolve(ok);
    };

    try {
      const check = spawn(
        getPythonExecutable(),
        [
          '-c',
          `
import sys, os
try:
    import joblib, sklearn, numpy, pandas, supabase
except ImportError as e:
    sys.stderr.write(f"Missing dependency: {e}\\n")
    sys.exit(1)

model_path = ${JSON.stringify(modelPath)}
if os.path.exists(model_path):
    try:
        artifact = joblib.load(model_path)
        model = artifact.get('model') if isinstance(artifact, dict) else artifact
        model_name = type(model).__name__
        print(f"[ML Startup] SUCCESS: Random Forest model artifact loaded successfully via joblib ({model_name}, sklearn {sklearn.__version__}, joblib {joblib.__version__})")
    except Exception as e:
        sys.stderr.write(f"Failed to load model: {e}\\n")
        sys.exit(2)
else:
    print(f"[ML Startup] Python ML libraries ready (sklearn {sklearn.__version__}, joblib {joblib.__version__}); model not trained yet.")
`
        ],
        { cwd: PROJECT_ROOT, env: process.env }
      );

      let stdout = '';
      let stderr = '';
      check.stdout.on('data', (d) => {
        stdout += d.toString();
      });
      check.stderr.on('data', (d) => {
        stderr += d.toString();
      });

      check.on('error', (err) => {
        console.error(`[ML Startup] Failed to spawn python3 during check: ${err.message}`);
        finish(false);
      });

      check.on('close', (code) => {
        if (code === 0) {
          if (stdout.trim()) console.log(stdout.trim());
          finish(true);
          return;
        }

        console.warn('[ML Startup] Initial check:', (stderr || stdout).trim());
        console.log('[ML Startup] Running scripts/setup_ml_env.sh to ensure all requirements.txt dependencies are installed...');
        const setupScript = path.resolve(PROJECT_ROOT, 'scripts/setup_ml_env.sh');
        try {
          const setup = spawn('bash', [setupScript], {
            cwd: PROJECT_ROOT,
            env: process.env,
            stdio: 'inherit'
          });
          setup.on('error', (err) => {
            console.error(`[ML Startup] Failed to run setup_ml_env.sh: ${err.message}`);
            finish(false);
          });
          setup.on('close', (setupCode) => {
            if (setupCode === 0) {
              console.log('[ML Startup] Environment setup complete. Model is ready for predictions.');
              finish(true);
            } else {
              console.error(`[ML Startup] Environment setup exited with code ${setupCode}`);
              finish(false);
            }
          });
        } catch (setupErr: any) {
          console.error(`[ML Startup] Setup invocation error: ${setupErr?.message || setupErr}`);
          finish(false);
        }
      });
    } catch (err: any) {
      console.error(`[ML Startup] Unexpected verification error: ${err?.message || err}`);
      finish(false);
    }
  });
}

// Mount Vite (dev) or serve static dist/ files (production)
async function startServer() {
  // Start ML verification concurrently so app.listen() binds immediately without blocking Cloud Run health checks
  mlSetupPromise = verifyModelArtifact().catch((err) => {
    console.error('[ML Startup] Verification failed:', err);
    mlReadyState = false;
    return false;
  });

  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(PROJECT_ROOT, 'dist');
    const indexHtml = path.resolve(distDir, 'index.html');
    app.use(express.static(distDir));
    app.get('*', (_req: Request, res: Response) => {
      if (fs.existsSync(indexHtml)) {
        res.sendFile(indexHtml);
      } else {
        res.status(503).send('Production build not found. Run npm run build.');
      }
    });
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Express] Server running on http://0.0.0.0:${PORT}`);
  });

  server.on('error', (err: any) => {
    console.error(`[Express] Server failed to bind to 0.0.0.0:${PORT}:`, err?.message || err);
    process.exit(1);
  });
}

startServer().catch((err) => {
  console.error('[Express] Fatal startup error:', err);
  process.exit(1);
});
