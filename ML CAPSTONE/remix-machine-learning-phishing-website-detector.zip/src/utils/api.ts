/**
 * Safely parses a Fetch API Response without throwing SyntaxError on non-JSON
 * responses (e.g., "Service Unavailable", HTML proxy error pages, or empty bodies).
 */
export async function parseApiResponse<T = any>(res: Response): Promise<T> {
  const rawText = await res.text();
  const trimmed = rawText.trim();

  let parsed: any = null;
  if (trimmed) {
    try {
      parsed = JSON.parse(trimmed);
    } catch {
      parsed = null;
    }
  }

  if (!res.ok) {
    if (parsed && typeof parsed === 'object') {
      const msg = parsed.error || parsed.message || `Request failed with HTTP ${res.status}`;
      throw new Error(String(msg));
    }

    if (res.status === 502 || res.status === 503 || res.status === 504) {
      const detail = trimmed && !trimmed.startsWith('<') ? trimmed : res.statusText || 'Service Unavailable';
      throw new Error(`Backend service is temporarily unavailable (HTTP ${res.status}: ${detail}). Please try again.`);
    }

    const snippet = trimmed && !trimmed.startsWith('<')
      ? trimmed.slice(0, 200)
      : res.statusText || `HTTP ${res.status}`;
    throw new Error(`Request failed (${res.status}): ${snippet}`);
  }

  if (parsed === null) {
    throw new Error(
      `Invalid non-JSON response received from server (HTTP ${res.status}).`
    );
  }

  return parsed as T;
}
