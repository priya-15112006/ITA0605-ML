import React, { useState } from 'react';
import { Search, ShieldCheck, ShieldAlert, AlertTriangle, ArrowRight, CheckCircle2, ChevronDown, ChevronUp, Cpu } from 'lucide-react';
import { PredictionResult } from '../types';
import { parseApiResponse } from '../utils/api';

interface Props {
  modelTrained: boolean;
}

const SAMPLE_URLS = [
  { label: 'Legitimate: Google', url: 'https://www.google.com/search?q=machine+learning' },
  { label: 'Legitimate: GitHub', url: 'https://github.com/scikit-learn/scikit-learn' },
  { label: 'Legitimate: Wikipedia', url: 'https://en.wikipedia.org/wiki/Phishing' },
  { label: 'Phishing Pattern: Fake Banking IP', url: 'http://192.168.1.100/secure-login/bank-account/update.php' },
  { label: 'Phishing Pattern: Credential Stealer', url: 'http://paypal-verification-account-security.xyz/login?id=user@gmail.com' },
  { label: 'Phishing Pattern: Deceptive Subdomain', url: 'https://appleid.apple.com.manage-security-check.top/auth/signin' }
];

export const UrlTestingPlayground: React.FC<Props> = ({ modelTrained }) => {
  const [testUrl, setTestUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showFeatures, setShowFeatures] = useState(false);

  const handlePredict = async (urlToTest?: string) => {
    const targetUrl = urlToTest || testUrl;
    if (!targetUrl.trim()) return;

    setLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: targetUrl.trim() })
      });

      const data = await parseApiResponse<PredictionResult>(res);

      setResult(data);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
      <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Live URL Phishing Inference</h3>
            <p className="text-xs text-slate-400">
              Evaluates new URLs in real time using the saved Random Forest joblib model.
            </p>
          </div>
        </div>
        {!modelTrained && (
          <span className="text-[11px] font-medium text-amber-400 bg-amber-950/40 border border-amber-800/40 px-2.5 py-1 rounded-full">
            Model file pending training
          </span>
        )}
      </div>

      {/* Input Field */}
      <div className="space-y-3 mb-4">
        <div className="relative">
          <input
            type="text"
            disabled={!modelTrained || loading}
            placeholder={
              modelTrained
                ? 'Enter a URL to evaluate (e.g. https://secure-bank-login.xyz/verify)...'
                : 'Train the model first using your Supabase dataset to enable live classification'
            }
            value={testUrl}
            onChange={(e) => setTestUrl(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handlePredict()}
            className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-4 pr-32 py-3 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500 font-mono disabled:opacity-50"
          />
          <button
            onClick={() => handlePredict()}
            disabled={!modelTrained || loading || !testUrl.trim()}
            className="absolute right-2 top-2 bottom-2 px-4 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition disabled:opacity-50 flex items-center gap-1.5"
          >
            {loading ? (
              'Analyzing...'
            ) : (
              <>
                <Search className="w-3.5 h-3.5" /> Classify
              </>
            )}
          </button>
        </div>

        {/* Sample URLs */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[11px] text-slate-500 mr-1">Presets:</span>
          {SAMPLE_URLS.map((sample, i) => (
            <button
              key={i}
              type="button"
              disabled={!modelTrained}
              onClick={() => {
                setTestUrl(sample.url);
                handlePredict(sample.url);
              }}
              className="text-[11px] bg-slate-950 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 rounded-md px-2 py-1 transition disabled:opacity-40"
            >
              {sample.label}
            </button>
          ))}
        </div>
      </div>

      {error && (
        <div className="p-3 bg-rose-500/20 border border-rose-500/30 rounded-xl text-xs text-rose-300 flex items-center gap-2 mb-4">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Prediction Result Display */}
      {result && (
        <div className="mt-4 border border-slate-800 rounded-xl overflow-hidden bg-slate-950/70 p-4">
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
            <div className="flex items-center gap-3">
              <div
                className={`p-3 rounded-xl ${
                  result.is_phishing
                    ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                    : 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                }`}
              >
                {result.is_phishing ? (
                  <ShieldAlert className="w-6 h-6" />
                ) : (
                  <ShieldCheck className="w-6 h-6" />
                )}
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span
                    className={`text-lg font-bold ${
                      result.is_phishing ? 'text-rose-400' : 'text-emerald-400'
                    }`}
                  >
                    {result.classification}
                  </span>
                  <span
                    className={`text-xs px-2 py-0.5 rounded font-semibold ${
                      result.risk_level === 'Critical'
                        ? 'bg-rose-900/60 text-rose-200 border border-rose-700'
                        : result.risk_level === 'High'
                        ? 'bg-amber-900/60 text-amber-200 border border-amber-700'
                        : result.risk_level === 'Moderate'
                        ? 'bg-yellow-900/40 text-yellow-200 border border-yellow-700'
                        : 'bg-emerald-900/40 text-emerald-200 border border-emerald-700'
                    }`}
                  >
                    Risk: {result.risk_level}
                  </span>
                </div>
                <div className="text-xs text-slate-400 font-mono break-all mt-0.5">
                  {result.url}
                </div>
              </div>
            </div>

            {/* Probability Gauges */}
            <div className="flex items-center gap-4 text-xs font-mono">
              <div className="text-right">
                <div className="text-slate-500">Phishing Prob.</div>
                <div
                  className={`text-base font-bold ${
                    result.is_phishing ? 'text-rose-400' : 'text-slate-400'
                  }`}
                >
                  {(result.phishing_probability * 100).toFixed(1)}%
                </div>
              </div>
              <div className="text-right">
                <div className="text-slate-500">Legitimate Prob.</div>
                <div
                  className={`text-base font-bold ${
                    !result.is_phishing ? 'text-emerald-400' : 'text-slate-400'
                  }`}
                >
                  {(result.legitimate_probability * 100).toFixed(1)}%
                </div>
              </div>
            </div>
          </div>

          {/* Flagged Indicators */}
          {result.indicators && result.indicators.length > 0 && (
            <div className="mt-3 bg-rose-950/20 border border-rose-900/30 rounded-lg p-3 text-xs space-y-1">
              <div className="font-semibold text-rose-300 flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-rose-400" />
                Flagged Heuristics & Suspicious Signals:
              </div>
              <ul className="list-disc list-inside text-rose-200/80 space-y-0.5 pl-1">
                {result.indicators.map((ind, i) => (
                  <li key={i}>{ind}</li>
                ))}
              </ul>
            </div>
          )}

          {/* Toggle All 22 Extracted Features */}
          <div className="mt-3 pt-3 border-t border-slate-800/80">
            <button
              onClick={() => setShowFeatures(!showFeatures)}
              className="text-xs text-cyan-400 hover:text-cyan-300 transition flex items-center gap-1 font-medium"
            >
              {showFeatures ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              {showFeatures ? 'Hide Extracted URL Features' : 'View All 22 Extracted Features'}
            </button>

            {showFeatures && result.extracted_features && (
              <div className="mt-2.5 grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 text-xs font-mono">
                {Object.entries(result.extracted_features).map(([key, val]) => (
                  <div
                    key={key}
                    className="p-2 rounded bg-slate-900 border border-slate-800 flex items-center justify-between"
                  >
                    <span className="text-slate-400 truncate mr-2">{key}</span>
                    <span className="font-semibold text-slate-200 shrink-0">{String(val)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
