import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Search,
  RefreshCw,
  AlertTriangle,
  Globe,
  Lock,
  Unlock,
  CheckCircle2,
  XCircle,
  Copy,
  Check,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Sparkles,
  Info
} from 'lucide-react';
import { PredictionResult } from '../types';
import { parseApiResponse } from '../utils/api';

interface Props {
  modelTrained: boolean;
}

const SAMPLE_PRESETS = [
  { label: 'Google Search', url: 'https://www.google.com/search?q=machine+learning', type: 'legit' },
  { label: 'GitHub Docs', url: 'https://github.com/scikit-learn/scikit-learn', type: 'legit' },
  { label: 'Wikipedia', url: 'https://en.wikipedia.org/wiki/Phishing', type: 'legit' },
  { label: 'Suspicious Banking IP', url: 'http://192.168.1.100/secure-login/bank-account/update.php', type: 'phish' },
  { label: 'Fake PayPal Verify', url: 'http://paypal-verification-account-security.xyz/login?id=user@gmail.com', type: 'phish' },
  { label: 'Deceptive AppleID', url: 'https://appleid.apple.com.manage-security-check.top/auth/signin', type: 'phish' },
];

export const UrlCheckerMain: React.FC<Props> = ({ modelTrained }) => {
  const [inputUrl, setInputUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [currentResult, setCurrentResult] = useState<PredictionResult | null>(null);
  const [showAllFeatures, setShowAllFeatures] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [history, setHistory] = useState<PredictionResult[]>([]);

  // Input validation
  const validateInput = (urlStr: string): string | null => {
    const trimmed = urlStr.trim();
    if (!trimmed) {
      return 'Please enter a website URL to analyze.';
    }
    if (trimmed.length < 3) {
      return 'URL is too short to be valid.';
    }
    if (/\s/.test(trimmed)) {
      return 'URLs cannot contain spaces. Please check the address.';
    }
    // Check basic domain structure (needs at least one dot or localhost/ip)
    const withoutScheme = trimmed.replace(/^(https?:\/\/)?/i, '');
    if (!withoutScheme.includes('.') && !withoutScheme.startsWith('localhost')) {
      return 'Please enter a valid domain name (e.g., example.com or https://example.com).';
    }
    return null;
  };

  const handleCheckUrl = async (urlToCheck?: string) => {
    const target = (urlToCheck || inputUrl).trim();
    setValidationError(null);
    setErrorMessage(null);

    const err = validateInput(target);
    if (err) {
      setValidationError(err);
      return;
    }

    // Auto-normalize scheme if missing for clean checking
    let normalized = target;
    if (!/^https?:\/\//i.test(normalized)) {
      normalized = 'https://' + normalized;
    }

    setIsLoading(true);

    try {
      const res = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: normalized })
      });

      const data = await parseApiResponse<PredictionResult>(res);

      setCurrentResult(data);
      // Append to history (avoid duplicates at the top)
      setHistory(prev => [data, ...prev.filter(item => item.url !== data.url)].slice(0, 5));
    } catch (err: any) {
      setErrorMessage(err.message || 'An unexpected error occurred while checking the URL.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyResult = () => {
    if (!currentResult) return;
    const summary = `URL: ${currentResult.url}\nVerdict: ${currentResult.classification}\nRisk Level: ${currentResult.risk_level}\nPhishing Probability: ${(currentResult.phishing_probability * 100).toFixed(1)}%\nIndicators: ${currentResult.indicators.join(', ') || 'None'}`;
    navigator.clipboard.writeText(summary);
    setCopiedUrl(true);
    setTimeout(() => setCopiedUrl(false), 2000);
  };

  const isPhishing = currentResult ? (currentResult.is_phishing || currentResult.classification === 'Potential Phishing' || currentResult.classification === 'Phishing') : false;

  return (
    <div className="space-y-8">
      {/* Hero Section */}
      <div className="text-center max-w-3xl mx-auto pt-4 sm:pt-6 pb-2">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-teal-500/10 border border-teal-500/25 text-teal-300 text-xs font-semibold uppercase tracking-wider mb-4 shadow-sm">
          <Sparkles className="w-3.5 h-3.5 text-teal-400" />
          <span>Random Forest ML Phishing Detection</span>
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-tight">
          Verify Any Website URL in Seconds
        </h1>
        <p className="mt-3.5 text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl mx-auto">
          Scans 22 lexical, structural, and character-entropy features using our trained Random Forest classifier to expose spoofed domains, deceptive subdomains, and credential theft traps.
        </p>
      </div>

      {/* Main URL Input Card */}
      <div className="max-w-3xl mx-auto">
        <div className="bg-[#0e1b36] border border-[#1e2f56] rounded-2xl p-4 sm:p-6 shadow-2xl shadow-slate-950/60 backdrop-blur-sm">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleCheckUrl();
            }}
            className="space-y-3.5"
          >
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-teal-400">
                <Globe className="w-5 h-5" />
              </div>
              <input
                type="text"
                autoFocus
                placeholder="Enter or paste website URL (e.g., https://secure-login-check.com)..."
                value={inputUrl}
                onChange={(e) => {
                  setInputUrl(e.target.value);
                  if (validationError) setValidationError(null);
                }}
                disabled={isLoading}
                className="w-full pl-12 pr-32 sm:pr-36 py-3.5 sm:py-4 bg-[#091224] border border-[#223661] rounded-xl text-slate-100 placeholder-slate-500 text-sm sm:text-base font-mono focus:outline-none focus:border-teal-400 focus:ring-2 focus:ring-teal-400/20 transition shadow-inner"
              />
              <button
                type="submit"
                disabled={isLoading || !inputUrl.trim()}
                className="absolute right-2 top-2 bottom-2 px-4 sm:px-6 rounded-lg bg-gradient-to-r from-teal-500 to-teal-600 hover:from-teal-400 hover:to-teal-500 text-white font-semibold text-xs sm:text-sm tracking-wide transition shadow-lg shadow-teal-500/25 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 cursor-pointer"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>Checking...</span>
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    <span>Check URL</span>
                  </>
                )}
              </button>
            </div>

            {/* Validation Error Message */}
            {validationError && (
              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-amber-400" />
                <span>{validationError}</span>
              </div>
            )}

            {/* Backend Service Error */}
            {errorMessage && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs flex items-center gap-2">
                <XCircle className="w-4 h-4 shrink-0 text-rose-400" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Quick Sample Presets */}
            <div className="pt-2 flex flex-wrap items-center gap-1.5 text-xs">
              <span className="text-slate-400 font-medium mr-1 text-[11px]">Test samples:</span>
              {SAMPLE_PRESETS.map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  disabled={isLoading}
                  onClick={() => {
                    setInputUrl(preset.url);
                    handleCheckUrl(preset.url);
                  }}
                  className={`px-2.5 py-1 rounded-md text-[11px] font-mono border transition flex items-center gap-1 cursor-pointer ${
                    preset.type === 'legit'
                      ? 'bg-[#132244] hover:bg-[#192d59] border-[#223661] text-slate-300 hover:text-teal-300'
                      : 'bg-rose-950/20 hover:bg-rose-950/40 border-rose-900/30 text-rose-300 hover:text-rose-200'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${preset.type === 'legit' ? 'bg-teal-400' : 'bg-rose-400'}`} />
                  {preset.label}
                </button>
              ))}
            </div>
          </form>
        </div>
      </div>

      {/* Model status alert if model hasn't been trained yet */}
      {!modelTrained && (
        <div className="max-w-3xl mx-auto p-4 rounded-xl bg-amber-950/30 border border-amber-800/40 text-amber-200 text-xs flex items-start gap-3">
          <Info className="w-4 h-4 mt-0.5 text-amber-400 shrink-0" />
          <div>
            <strong>Notice:</strong> The Random Forest model artifact is currently not detected. Go to the <strong>Model & Database</strong> tab to run the benchmark training on your Supabase dataset to activate inference.
          </div>
        </div>
      )}

      {/* Verification Result Card */}
      {currentResult && (
        <div className="max-w-3xl mx-auto animate-in fade-in slide-in-from-bottom-3 duration-300">
          <div
            className={`border rounded-2xl overflow-hidden shadow-2xl ${
              isPhishing
                ? 'bg-gradient-to-b from-[#1c1324] to-[#0f182d] border-rose-500/40 shadow-rose-950/40'
                : 'bg-gradient-to-b from-[#0d222f] to-[#0f1b34] border-teal-500/40 shadow-teal-950/40'
            }`}
          >
            {/* Verdict Header Banner */}
            <div
              className={`p-5 sm:p-6 border-b flex flex-wrap items-center justify-between gap-4 ${
                isPhishing
                  ? 'border-rose-500/20 bg-rose-950/30'
                  : 'border-teal-500/20 bg-teal-950/30'
              }`}
            >
              <div className="flex items-center gap-3.5">
                <div
                  className={`p-3 rounded-2xl ${
                    isPhishing
                      ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                      : 'bg-teal-500/20 text-teal-400 border border-teal-500/30'
                  }`}
                >
                  {isPhishing ? (
                    <ShieldAlert className="w-8 h-8" />
                  ) : (
                    <ShieldCheck className="w-8 h-8" />
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <span
                      className={`text-xl sm:text-2xl font-black tracking-tight ${
                        isPhishing ? 'text-rose-400' : 'text-teal-400'
                      }`}
                    >
                      {currentResult.classification === 'Phishing' || isPhishing
                        ? 'Potential Phishing'
                        : 'Likely Legitimate'}
                    </span>
                    <span
                      className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider border ${
                        currentResult.risk_level === 'Critical'
                          ? 'bg-rose-900/60 text-rose-200 border-rose-600'
                          : currentResult.risk_level === 'High'
                          ? 'bg-amber-900/60 text-amber-200 border-amber-600'
                          : currentResult.risk_level === 'Moderate'
                          ? 'bg-yellow-900/50 text-yellow-200 border-yellow-600'
                          : 'bg-teal-900/50 text-teal-200 border-teal-600'
                      }`}
                    >
                      Risk: {currentResult.risk_level}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 mt-1">
                    {isPhishing
                      ? 'Warning: This URL displays statistical and structural anomalies characteristic of phishing.'
                      : 'Safe: URL structural and lexical patterns correspond to legitimate domains.'}
                  </p>
                </div>
              </div>

              {/* Confidence / Probability Badge */}
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <div className="text-[11px] uppercase font-mono tracking-wider text-slate-400">
                    Model Confidence
                  </div>
                  <div
                    className={`text-2xl font-black font-mono ${
                      isPhishing ? 'text-rose-400' : 'text-teal-400'
                    }`}
                  >
                    {isPhishing
                      ? `${(currentResult.phishing_probability * 100).toFixed(1)}%`
                      : `${(currentResult.legitimate_probability * 100).toFixed(1)}%`}
                  </div>
                </div>
                <button
                  onClick={handleCopyResult}
                  title="Copy analysis summary"
                  className="p-2 rounded-lg bg-[#142347] hover:bg-[#1a2f5f] border border-[#233a6e] text-slate-300 hover:text-white transition cursor-pointer"
                >
                  {copiedUrl ? <Check className="w-4 h-4 text-teal-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* URL Display */}
            <div className="px-5 sm:px-6 py-3 bg-[#0a1224]/80 border-b border-[#1e2f56] flex items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 overflow-hidden">
                <span className="text-slate-400 font-semibold shrink-0">Analyzed URL:</span>
                <span className="font-mono text-slate-200 truncate">{currentResult.url}</span>
              </div>
              <a
                href={currentResult.url}
                target="_blank"
                rel="noreferrer noopener"
                className="text-[11px] text-teal-400 hover:text-teal-300 flex items-center gap-1 shrink-0"
              >
                <span>Inspect</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            {/* Suspicious Features Detected (Requirement 4) */}
            <div className="p-5 sm:p-6 space-y-4">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2 mb-2.5">
                  <AlertTriangle className={`w-4 h-4 ${isPhishing ? 'text-rose-400' : 'text-teal-400'}`} />
                  Suspicious URL Features Detected
                </h3>

                {currentResult.indicators && currentResult.indicators.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {currentResult.indicators.map((indicator, idx) => (
                      <div
                        key={idx}
                        className="p-3 rounded-xl bg-rose-950/20 border border-rose-900/30 text-rose-200 text-xs flex items-start gap-2.5"
                      >
                        <XCircle className="w-4 h-4 text-rose-400 mt-0.5 shrink-0" />
                        <span className="font-medium leading-relaxed">{indicator}</span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="p-3.5 rounded-xl bg-teal-950/20 border border-teal-900/30 text-teal-200 text-xs flex items-center gap-2.5">
                    <CheckCircle2 className="w-4 h-4 text-teal-400 shrink-0" />
                    <span>No anomalous structural markers, credential spoofing symbols, or deceptive keywords detected.</span>
                  </div>
                )}
              </div>

              {/* Key URL Dimensions Breakdown */}
              {currentResult.extracted_features && (
                <div className="pt-2">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2.5">
                    Key URL Metrics (Python Feature Extraction)
                  </h4>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono">
                    {/* HTTPS Protocol */}
                    <div className="p-3 rounded-xl bg-[#0b152b] border border-[#1d3059]">
                      <div className="text-[11px] text-slate-400 font-sans flex items-center gap-1 mb-1">
                        {currentResult.extracted_features.is_https === 1 ? (
                          <Lock className="w-3.5 h-3.5 text-teal-400" />
                        ) : (
                          <Unlock className="w-3.5 h-3.5 text-amber-400" />
                        )}
                        <span>Protocol</span>
                      </div>
                      <div className={`font-bold ${currentResult.extracted_features.is_https === 1 ? 'text-teal-400' : 'text-amber-400'}`}>
                        {currentResult.extracted_features.is_https === 1 ? 'HTTPS (Secure)' : 'HTTP (Insecure)'}
                      </div>
                    </div>

                    {/* Character Entropy */}
                    <div className="p-3 rounded-xl bg-[#0b152b] border border-[#1d3059]">
                      <div className="text-[11px] text-slate-400 font-sans mb-1">Character Entropy</div>
                      <div className="font-bold text-white">
                        {Number(currentResult.extracted_features.entropy).toFixed(2)}{' '}
                        <span className="text-[10px] text-slate-400 font-normal">
                          {Number(currentResult.extracted_features.entropy) > 4.5 ? '(High randomness)' : '(Normal)'}
                        </span>
                      </div>
                    </div>

                    {/* URL Length */}
                    <div className="p-3 rounded-xl bg-[#0b152b] border border-[#1d3059]">
                      <div className="text-[11px] text-slate-400 font-sans mb-1">Total URL Length</div>
                      <div className="font-bold text-white">
                        {currentResult.extracted_features.url_length} chars
                      </div>
                    </div>

                    {/* Domain & Subdomains */}
                    <div className="p-3 rounded-xl bg-[#0b152b] border border-[#1d3059]">
                      <div className="text-[11px] text-slate-400 font-sans mb-1">Subdomain Count</div>
                      <div className="font-bold text-white">
                        {currentResult.extracted_features.count_subdomains}{' '}
                        <span className="text-[10px] text-slate-400 font-normal">levels</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Collapsible: All 22 Features Table */}
              <div className="pt-2">
                <button
                  type="button"
                  onClick={() => setShowAllFeatures(!showAllFeatures)}
                  className="w-full py-2 px-3 rounded-xl bg-[#0b152b] hover:bg-[#111f3d] border border-[#1d3059] text-xs font-semibold text-teal-400 hover:text-teal-300 transition flex items-center justify-between cursor-pointer"
                >
                  <span>{showAllFeatures ? 'Hide All 22 Extracted Features' : 'Inspect All 22 Extracted URL Features'}</span>
                  {showAllFeatures ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                </button>

                {showAllFeatures && currentResult.extracted_features && (
                  <div className="mt-2.5 p-3 rounded-xl bg-[#091224] border border-[#1d3059] grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 text-xs font-mono">
                    {Object.entries(currentResult.extracted_features).map(([featKey, featVal]) => (
                      <div
                        key={featKey}
                        className="p-2 rounded-lg bg-[#0e1b36] border border-[#1a2d54] flex items-center justify-between"
                      >
                        <span className="text-slate-400 text-[11px] truncate mr-2">{featKey}</span>
                        <span className="font-bold text-slate-100">{String(featVal)}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Recent Checks Session History */}
      {history.length > 1 && (
        <div className="max-w-3xl mx-auto pt-2">
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3">
            Recent Scans This Session
          </h3>
          <div className="space-y-2">
            {history.map((item, i) => {
              const itemIsPhish = item.is_phishing || item.classification === 'Potential Phishing' || item.classification === 'Phishing';
              return (
                <div
                  key={i}
                  onClick={() => setCurrentResult(item)}
                  className="p-3 rounded-xl bg-[#0e1b36] hover:bg-[#132347] border border-[#1e2f56] flex items-center justify-between gap-3 text-xs transition cursor-pointer"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    {itemIsPhish ? (
                      <ShieldAlert className="w-4 h-4 text-rose-400 shrink-0" />
                    ) : (
                      <ShieldCheck className="w-4 h-4 text-teal-400 shrink-0" />
                    )}
                    <span className="font-mono text-slate-300 truncate">{item.url}</span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`font-semibold px-2 py-0.5 rounded text-[11px] ${
                        itemIsPhish
                          ? 'bg-rose-950/40 text-rose-300 border border-rose-800/40'
                          : 'bg-teal-950/40 text-teal-300 border border-teal-800/40'
                      }`}
                    >
                      {itemIsPhish ? 'Potential Phishing' : 'Likely Legitimate'}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
