import React from 'react';
import { BarChart3, HelpCircle } from 'lucide-react';
import { ModelInfo } from '../types';

interface Props {
  modelInfo: ModelInfo | null | undefined;
}

export const FeatureImportanceChart: React.FC<Props> = ({ modelInfo }) => {
  if (!modelInfo || !modelInfo.feature_importances || modelInfo.feature_importances.length === 0) {
    return null;
  }

  const importances = modelInfo.feature_importances;
  const maxImp = Math.max(...importances.map(f => f.importance), 0.001);

  const featureLabels: Record<string, string> = {
    url_length: 'Total URL Length',
    domain_length: 'Hostname / Domain Length',
    path_length: 'Path Length',
    count_dots: 'Count of Dots (.)',
    count_hyphens: 'Count of Hyphens (-)',
    count_underscores: 'Count of Underscores (_)',
    count_slashes: 'Count of Slashes (/)',
    count_question_marks: 'Count of Question Marks (?)',
    count_equals: 'Count of Equal Signs (=)',
    count_at: 'Count of @ Signs (Obfuscation)',
    count_ampersand: 'Count of Ampersands (&)',
    count_percent: 'Count of % Signs (Encoding)',
    count_digits: 'Total Digit Count',
    digit_ratio: 'Digit to Length Ratio',
    count_letters: 'Alphabetic Letter Count',
    is_https: 'HTTPS Protocol Usage',
    has_ip_address: 'Raw IPv4 Address in Domain',
    count_subdomains: 'Subdomain Count (Domain Structure)',
    has_suspicious_keywords: 'Phishing Keyword Presence',
    tld_in_path: 'TLD Masked in Path/Query',
    is_shortener: 'URL Shortener Service Domain',
    entropy: 'Shannon Character Entropy (Randomness)'
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
      <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
            <BarChart3 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Feature Importance Ranking (MDI)</h3>
            <p className="text-xs text-slate-400">
              Mean Decrease in Impurity across all Random Forest decision trees for {importances.length} URL features.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-3">
        {importances.slice(0, 16).map((item, idx) => {
          const percentage = (item.importance / maxImp) * 100;
          const readableName = featureLabels[item.feature] || item.feature;

          return (
            <div key={item.feature} className="space-y-1">
              <div className="flex items-center justify-between text-xs">
                <span className="text-slate-300 font-medium flex items-center gap-1.5">
                  <span className="font-mono text-slate-500 text-[10px]">#{idx + 1}</span>
                  {readableName}
                </span>
                <span className="font-mono text-cyan-400 font-semibold text-[11px]">
                  {(item.importance * 100).toFixed(2)}%
                </span>
              </div>
              <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-800">
                <div
                  className="bg-gradient-to-r from-cyan-600 to-indigo-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.max(percentage, 2)}%` }}
                />
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-4 pt-3 border-t border-slate-800 flex items-center gap-2 text-[11px] text-slate-500">
        <HelpCircle className="w-3.5 h-3.5 text-slate-400 shrink-0" />
        <span>
          Features with highest impurity reduction drive the model&apos;s ability to discriminate between phishing websites and legitimate domains.
        </span>
      </div>
    </div>
  );
};
