import React from 'react';
import { Terminal, Cpu, Database, CheckCircle2, AlertTriangle, ShieldCheck } from 'lucide-react';
import { BackendInfo } from '../types';

interface Props {
  info: BackendInfo | null;
  onOpenConfig: () => void;
  onRefresh: () => void;
  isTestingConnection: boolean;
}

export const BackendStatusBadge: React.FC<Props> = ({
  info,
  onOpenConfig,
  onRefresh,
  isTestingConnection
}) => {
  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 shadow-lg backdrop-blur-sm">
      <div className="flex flex-wrap items-center justify-between gap-4">
        {/* Python & Scikit-learn Runtime */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-emerald-400">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold tracking-wider uppercase text-slate-400">ML Backend Runtime</span>
              <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                <CheckCircle2 className="w-3 h-3" /> Verified Active
              </span>
            </div>
            <div className="text-sm font-semibold text-slate-200">
              Python 3.10 • Scikit-learn {info?.scikitLearnVersion || '1.7.2'}
            </div>
            <div className="text-xs text-slate-500">
              Native Random Forest Classifier (No JS heuristics)
            </div>
          </div>
        </div>

        {/* Database Status */}
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-lg border ${
            info?.supabaseConfigured
              ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
              : 'bg-amber-500/10 border-amber-500/20 text-amber-400'
          }`}>
            <Database className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold tracking-wider uppercase text-slate-400">Supabase Database</span>
              {info?.supabaseConfigured ? (
                <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                  <CheckCircle2 className="w-3 h-3" /> Credentials Set
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-[11px] font-medium px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
                  <AlertTriangle className="w-3 h-3" /> Action Required
                </span>
              )}
            </div>
            <div className="text-sm font-semibold text-slate-200">
              Table: <span className="font-mono text-cyan-400">{info?.supabaseTable || 'phishing_dataset'}</span> (~340k records)
            </div>
            <div className="text-xs text-slate-500">
              Paginated batch streaming via server backend
            </div>
          </div>
        </div>

        {/* Model State & Buttons */}
        <div className="flex items-center gap-2.5">
          <button
            onClick={onOpenConfig}
            className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 hover:border-slate-600 transition flex items-center gap-1.5 shadow-sm"
          >
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            Supabase Settings
          </button>
          <button
            onClick={onRefresh}
            disabled={isTestingConnection}
            className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white transition flex items-center gap-1.5 shadow-sm disabled:opacity-50"
          >
            <Terminal className="w-4 h-4" />
            {isTestingConnection ? 'Testing...' : 'Test DB Connection'}
          </button>
        </div>
      </div>
    </div>
  );
};
