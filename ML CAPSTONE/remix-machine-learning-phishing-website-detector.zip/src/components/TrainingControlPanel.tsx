import React, { useState } from 'react';
import { Play, Sliders, Database, Layers, Sparkles, RefreshCw } from 'lucide-react';
import { TrainingJobStatus } from '../types';

interface Props {
  onStartTraining: (params: {
    batchSize: number;
    maxRecords?: number;
    testSize: number;
    nEstimators: number;
    maxDepth: number;
  }) => void;
  jobStatus: TrainingJobStatus;
  supabaseConfigured: boolean;
}

export const TrainingControlPanel: React.FC<Props> = ({
  onStartTraining,
  jobStatus,
  supabaseConfigured
}) => {
  const [batchSize, setBatchSize] = useState<number>(1000);
  const [recordPreset, setRecordPreset] = useState<string>('10000');
  const [testSplit, setTestSplit] = useState<number>(0.2);
  const [nEstimators, setNEstimators] = useState<number>(100);
  const [maxDepth, setMaxDepth] = useState<number>(25);

  const isRunning = jobStatus.status === 'running';

  const handleLaunch = () => {
    const maxRec = recordPreset === 'all' ? undefined : parseInt(recordPreset, 10);
    onStartTraining({
      batchSize,
      maxRecords: maxRec,
      testSize: testSplit,
      nEstimators,
      maxDepth
    });
  };

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
      <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
            <Sliders className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold text-white">Pipeline & Model Controls</h2>
            <p className="text-xs text-slate-400">
              Configure batch pagination, data splitting, and Random Forest hyperparameters.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-5">
        {/* Dataset Volume */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <Database className="w-3.5 h-3.5 text-cyan-400" />
            Dataset Volume
          </label>
          <select
            value={recordPreset}
            disabled={isRunning}
            onChange={(e) => setRecordPreset(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs font-medium text-slate-200 focus:outline-none focus:border-cyan-500"
          >
            <option value="10">10 records (Quick Verification & Sanity Check)</option>
            <option value="1000">1,000 records (Small batch check - ~5s)</option>
            <option value="5000">5,000 records (Rapid test - ~15s)</option>
            <option value="10000">10,000 records (Standard benchmark - ~30s)</option>
            <option value="25000">25,000 records (Robust sample - ~1m)</option>
            <option value="50000">50,000 records (High fidelity - ~2m)</option>
            <option value="100000">100,000 records (Deep sample - ~4m)</option>
            <option value="all">All ~340,000 records (Full production dataset)</option>
          </select>
          <span className="text-[11px] text-slate-500 mt-1 block">
            Handles pagination in batches without PostgREST row limits.
          </span>
        </div>

        {/* Batch Size */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            Batch Size
          </label>
          <select
            value={batchSize}
            disabled={isRunning}
            onChange={(e) => setBatchSize(Number(e.target.value))}
            className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs font-medium text-slate-200 focus:outline-none focus:border-cyan-500"
          >
            <option value={500}>500 records / batch</option>
            <option value={1000}>1,000 records / batch (Recommended)</option>
            <option value={2000}>2,000 records / batch</option>
          </select>
          <span className="text-[11px] text-slate-500 mt-1 block">
            Range bounds per HTTP query to Supabase.
          </span>
        </div>

        {/* Test Set Split */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            Test Split Ratio
          </label>
          <select
            value={testSplit}
            disabled={isRunning}
            onChange={(e) => setTestSplit(Number(e.target.value))}
            className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3 py-2 text-xs font-medium text-slate-200 focus:outline-none focus:border-cyan-500"
          >
            <option value={0.15}>15% Holdout Test (85% Train)</option>
            <option value={0.20}>20% Holdout Test (80% Train - Standard)</option>
            <option value={0.25}>25% Holdout Test (75% Train)</option>
            <option value={0.30}>30% Holdout Test (70% Train)</option>
          </select>
          <span className="text-[11px] text-slate-500 mt-1 block">
            Stratified holdout set for authentic metrics calculation.
          </span>
        </div>

        {/* Random Forest Estimators */}
        <div>
          <label className="block text-xs font-semibold text-slate-300 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
            <Sliders className="w-3.5 h-3.5 text-cyan-400" />
            Random Forest Trees
          </label>
          <div className="flex gap-2">
            <select
              value={nEstimators}
              disabled={isRunning}
              onChange={(e) => setNEstimators(Number(e.target.value))}
              className="w-1/2 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-2 text-xs font-medium text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value={50}>50 trees</option>
              <option value={100}>100 trees</option>
              <option value={150}>150 trees</option>
            </select>
            <select
              value={maxDepth}
              disabled={isRunning}
              onChange={(e) => setMaxDepth(Number(e.target.value))}
              className="w-1/2 bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-2 text-xs font-medium text-slate-200 focus:outline-none focus:border-cyan-500"
            >
              <option value={15}>Depth: 15</option>
              <option value={20}>Depth: 20</option>
              <option value={25}>Depth: 25</option>
            </select>
          </div>
          <span className="text-[11px] text-slate-500 mt-1 block">
            Controls tree ensemble capacity and depth limit.
          </span>
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800">
        <div className="text-xs text-slate-400">
          {!supabaseConfigured ? (
            <span className="text-amber-400 flex items-center gap-1.5">
              ⚠️ Please configure Supabase URL & Key above before training on real data.
            </span>
          ) : (
            <span className="text-emerald-400 flex items-center gap-1.5">
              ✓ Ready to retrieve records, extract 22 URL features, and train Random Forest.
            </span>
          )}
        </div>

        <button
          onClick={handleLaunch}
          disabled={isRunning}
          className={`px-5 py-2.5 rounded-lg text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition shadow-md ${
            isRunning
              ? 'bg-amber-600/60 text-white cursor-wait'
              : !supabaseConfigured
              ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700'
              : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-emerald-950/50'
          }`}
        >
          {isRunning ? (
            <>
              <RefreshCw className="w-4 h-4 animate-spin text-white" />
              Training Pipeline Running...
            </>
          ) : (
            <>
              <Play className="w-4 h-4 fill-current" />
              Train Random Forest Classifier
            </>
          )}
        </button>
      </div>
    </div>
  );
};
