import React, { useState } from 'react';
import { X, Lock, Key, Link as LinkIcon, Database, AlertCircle, CheckCircle2 } from 'lucide-react';
import { parseApiResponse } from '../utils/api';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  defaultTable?: string;
}

export const SupabaseConfigModal: React.FC<Props> = ({
  isOpen,
  onClose,
  onSuccess,
  defaultTable = 'phishing_dataset'
}) => {
  const [supabaseUrl, setSupabaseUrl] = useState('');
  const [supabaseKey, setSupabaseKey] = useState('');
  const [tableName, setTableName] = useState(defaultTable);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!supabaseUrl.trim() || !supabaseKey.trim()) {
      setMessage({ text: 'Please provide both Supabase URL and Key.', type: 'error' });
      return;
    }

    setIsSaving(true);
    setMessage(null);

    try {
      const res = await fetch('/api/supabase/configure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          supabaseUrl: supabaseUrl.trim(),
          supabaseKey: supabaseKey.trim(),
          tableName: tableName.trim() || 'phishing_dataset'
        })
      });

      await parseApiResponse(res);

      setMessage({ text: 'Credentials securely stored on backend server!', type: 'success' });
      setTimeout(() => {
        onSuccess();
        onClose();
      }, 1200);
    } catch (err: any) {
      setMessage({ text: err.message, type: 'error' });
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl p-6 shadow-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400">
            <Lock className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Configure Supabase Database</h3>
            <p className="text-xs text-slate-400">
              Credentials are saved securely in server-side environment variables (.env).
            </p>
          </div>
        </div>

        <div className="bg-emerald-950/40 border border-emerald-800/40 rounded-lg p-3 mb-5 text-xs text-emerald-300 flex items-start gap-2.5">
          <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0 text-emerald-400" />
          <div>
            <strong>Security Enforced:</strong> Keys are used strictly by the backend Node/Python processes to paginate records. No service keys or database credentials are ever exposed in frontend client scripts.
          </div>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5 flex items-center gap-1.5">
              <LinkIcon className="w-3.5 h-3.5 text-cyan-400" />
              Supabase Project URL
            </label>
            <input
              type="text"
              required
              placeholder="https://xyzcompany.supabase.co"
              value={supabaseUrl}
              onChange={(e) => setSupabaseUrl(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2.5 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500 font-mono"
            />
            <span className="text-[11px] text-slate-500 mt-1 block">
              Found under Supabase Dashboard &gt; Project Settings &gt; API &gt; Project URL (e.g. <code className="text-cyan-300">https://xyz.supabase.co</code>). Any trailing <code className="text-slate-400">/rest/v1</code> is automatically stripped.
            </span>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-cyan-400" />
              Supabase Secret / Service Role Key
            </label>
            <input
              type="password"
              required
              placeholder="sb_secret_... or eyJhbGciOi..."
              value={supabaseKey}
              onChange={(e) => setSupabaseKey(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2.5 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500 font-mono"
            />
            <span className="text-[11px] text-slate-500 mt-1 block">
              Use your <code className="text-cyan-300">service_role</code> or Secret Key (<code className="text-cyan-300">sb_secret_...</code>). Publishable/anon keys are blocked by PostgreSQL Row Level Security (RLS) on this table.
            </span>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-300 mb-1.5 flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5 text-cyan-400" />
              Table Name
            </label>
            <input
              type="text"
              required
              placeholder="phishing_dataset"
              value={tableName}
              onChange={(e) => setTableName(e.target.value)}
              className="w-full bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2.5 text-sm text-slate-100 placeholder-slate-600 focus:outline-none focus:border-cyan-500 font-mono"
            />
            <span className="text-[11px] text-slate-500 mt-1 block">
              Table containing columns <code className="text-cyan-300">url</code> and <code className="text-cyan-300">label</code>.
            </span>
          </div>

          {message && (
            <div className={`p-3 rounded-lg text-xs flex items-center gap-2 ${
              message.type === 'success'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
            }`}>
              {message.type === 'success' ? <CheckCircle2 className="w-4 h-4 shrink-0" /> : <AlertCircle className="w-4 h-4 shrink-0" />}
              <span>{message.text}</span>
            </div>
          )}

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 transition"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-5 py-2 text-xs font-semibold rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white transition disabled:opacity-50 flex items-center gap-2"
            >
              {isSaving ? 'Saving to Server...' : 'Save & Secure'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
