import React, { useEffect, useRef } from 'react';
import { Terminal, CheckCircle, AlertCircle, RefreshCw, Copy, Check } from 'lucide-react';
import { TrainingJobStatus } from '../types';

interface Props {
  job: TrainingJobStatus;
}

export const TrainingConsoleLogs: React.FC<Props> = ({ job }) => {
  const terminalRef = useRef<HTMLDivElement>(null);
  const [copied, setCopied] = React.useState(false);

  useEffect(() => {
    if (terminalRef.current) {
      terminalRef.current.scrollTop = terminalRef.current.scrollHeight;
    }
  }, [job.logs]);

  const handleCopy = () => {
    navigator.clipboard.writeText(job.logs.join('\n'));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-slate-950 border border-slate-800 rounded-xl overflow-hidden shadow-xl">
      {/* Console Header */}
      <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <Terminal className="w-4 h-4 text-cyan-400" />
          <span className="text-xs font-mono font-semibold text-slate-200">
            Pipeline Execution Console (stdout/stderr)
          </span>
          {job.status === 'running' && (
            <span className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30">
              <RefreshCw className="w-2.5 h-2.5 animate-spin" /> RUNNING
            </span>
          )}
          {job.status === 'completed' && (
            <span className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              <CheckCircle className="w-2.5 h-2.5" /> COMPLETED
            </span>
          )}
          {job.status === 'error' && (
            <span className="inline-flex items-center gap-1 text-[10px] font-mono px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30">
              <AlertCircle className="w-2.5 h-2.5" /> FAILED
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {job.logs.length > 0 && (
            <button
              onClick={handleCopy}
              className="text-xs text-slate-400 hover:text-white px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 transition flex items-center gap-1 font-mono"
            >
              {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
              {copied ? 'Copied' : 'Copy Logs'}
            </button>
          )}
        </div>
      </div>

      {/* Terminal View */}
      <div
        ref={terminalRef}
        className="p-4 font-mono text-xs text-slate-300 h-64 overflow-y-auto space-y-1 bg-black/60 scrollbar-thin scrollbar-thumb-slate-800"
      >
        {job.logs.length === 0 ? (
          <div className="text-slate-600 italic py-6 text-center">
            [Ready] Pipeline idle. Configure Supabase above and click 'Train Random Forest Classifier' to stream logs.
          </div>
        ) : (
          job.logs.map((log, idx) => {
            const isError = log.includes('[WARN/ERR]') || log.includes('ERROR:') || log.includes('Failed');
            const isSuccess = log.includes('SUCCESS:') || log.includes('completed in') || log.includes('Accuracy:');
            const isBatch = log.includes('[Batch') || log.includes('[Supabase]');

            return (
              <div
                key={idx}
                className={`leading-relaxed break-all ${
                  isError
                    ? 'text-rose-400 font-semibold'
                    : isSuccess
                    ? 'text-emerald-400 font-semibold'
                    : isBatch
                    ? 'text-cyan-300'
                    : 'text-slate-300'
                }`}
              >
                {log}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
