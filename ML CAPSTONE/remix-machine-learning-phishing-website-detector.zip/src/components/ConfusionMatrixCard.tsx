import React from 'react';
import { Grid, ShieldAlert, ShieldCheck } from 'lucide-react';
import { ModelInfo } from '../types';

interface Props {
  modelInfo: ModelInfo | null | undefined;
}

export const ConfusionMatrixCard: React.FC<Props> = ({ modelInfo }) => {
  if (!modelInfo || !modelInfo.confusion_matrix) {
    return null;
  }

  const { confusion_matrix: cm, classification_report: report } = modelInfo;
  const { true_negatives: tn, false_positives: fp, false_negatives: fn, true_positives: tp } = cm;
  const totalTest = tn + fp + fn + tp;

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
      <div className="flex items-center justify-between pb-3 mb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-rose-500/10 border border-rose-500/20 text-rose-400">
            <Grid className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">Confusion Matrix & Classification Report</h3>
            <p className="text-xs text-slate-400">
              Evaluated on {totalTest.toLocaleString()} test records across binary classes (0 = Legitimate, 1 = Phishing).
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-start">
        {/* Visual 2x2 Matrix */}
        <div>
          <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2.5">
            2×2 Contingency Table
          </div>

          <div className="border border-slate-700/80 rounded-xl overflow-hidden bg-slate-950">
            <div className="grid grid-cols-3 text-center text-xs font-semibold border-b border-slate-800 bg-slate-900/80 py-2">
              <div className="text-slate-500 font-mono">Actual \ Predicted</div>
              <div className="text-emerald-400 flex items-center justify-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" /> Pred. Legit (0)
              </div>
              <div className="text-rose-400 flex items-center justify-center gap-1">
                <ShieldAlert className="w-3.5 h-3.5" /> Pred. Phishing (1)
              </div>
            </div>

            {/* Row 1: Actual Legitimate */}
            <div className="grid grid-cols-3 border-b border-slate-800/80">
              <div className="bg-slate-900/40 p-3 text-xs font-semibold text-slate-300 flex items-center justify-center border-r border-slate-800">
                Actual Legit (0)
              </div>
              {/* True Negative */}
              <div className="p-3 bg-emerald-950/20 border-r border-slate-800 text-center">
                <div className="text-xs text-emerald-400 font-medium">True Negative (TN)</div>
                <div className="text-xl font-bold font-mono text-emerald-300">{tn.toLocaleString()}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {((tn / Math.max(tn + fp, 1)) * 100).toFixed(1)}% of Actual Legit
                </div>
              </div>
              {/* False Positive */}
              <div className="p-3 bg-rose-950/20 text-center">
                <div className="text-xs text-amber-400 font-medium">False Positive (FP)</div>
                <div className="text-xl font-bold font-mono text-amber-300">{fp.toLocaleString()}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {((fp / Math.max(tn + fp, 1)) * 100).toFixed(1)}% false alarms
                </div>
              </div>
            </div>

            {/* Row 2: Actual Phishing */}
            <div className="grid grid-cols-3">
              <div className="bg-slate-900/40 p-3 text-xs font-semibold text-slate-300 flex items-center justify-center border-r border-slate-800">
                Actual Phish (1)
              </div>
              {/* False Negative */}
              <div className="p-3 bg-rose-950/30 border-r border-slate-800 text-center">
                <div className="text-xs text-rose-400 font-medium">False Negative (FN)</div>
                <div className="text-xl font-bold font-mono text-rose-400">{fn.toLocaleString()}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {((fn / Math.max(fn + tp, 1)) * 100).toFixed(1)}% missed threats
                </div>
              </div>
              {/* True Positive */}
              <div className="p-3 bg-emerald-950/30 text-center">
                <div className="text-xs text-emerald-400 font-medium">True Positive (TP)</div>
                <div className="text-xl font-bold font-mono text-emerald-300">{tp.toLocaleString()}</div>
                <div className="text-[10px] text-slate-400 mt-0.5">
                  {((tp / Math.max(fn + tp, 1)) * 100).toFixed(1)}% threats caught
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Detailed Scikit-learn Classification Report */}
        <div>
          <div className="text-xs font-semibold text-slate-300 uppercase tracking-wider mb-2.5">
            Class-wise Precision, Recall & Support
          </div>

          <div className="border border-slate-700/80 rounded-xl overflow-hidden bg-slate-950">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-900/80 border-b border-slate-800 text-slate-400 font-mono">
                <tr>
                  <th className="py-2.5 px-3">Class</th>
                  <th className="py-2.5 px-3">Precision</th>
                  <th className="py-2.5 px-3">Recall</th>
                  <th className="py-2.5 px-3">F1-Score</th>
                  <th className="py-2.5 px-3 text-right">Support</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/80 font-mono">
                {report?.['0'] && (
                  <tr>
                    <td className="py-2 px-3 text-emerald-400 font-sans font-semibold">Legitimate (0)</td>
                    <td className="py-2 px-3 text-slate-200">{(report['0'].precision * 100).toFixed(1)}%</td>
                    <td className="py-2 px-3 text-slate-200">{(report['0'].recall * 100).toFixed(1)}%</td>
                    <td className="py-2 px-3 text-slate-200">{(report['0']['f1-score'] * 100).toFixed(1)}%</td>
                    <td className="py-2 px-3 text-right text-slate-400">{report['0'].support?.toLocaleString()}</td>
                  </tr>
                )}
                {report?.['1'] && (
                  <tr>
                    <td className="py-2 px-3 text-rose-400 font-sans font-semibold">Phishing (1)</td>
                    <td className="py-2 px-3 text-slate-200">{(report['1'].precision * 100).toFixed(1)}%</td>
                    <td className="py-2 px-3 text-slate-200">{(report['1'].recall * 100).toFixed(1)}%</td>
                    <td className="py-2 px-3 text-slate-200">{(report['1']['f1-score'] * 100).toFixed(1)}%</td>
                    <td className="py-2 px-3 text-right text-slate-400">{report['1'].support?.toLocaleString()}</td>
                  </tr>
                )}
                {report?.['macro avg'] && (
                  <tr className="bg-slate-900/30 text-slate-300">
                    <td className="py-2 px-3 font-sans font-medium text-slate-400">Macro Avg</td>
                    <td className="py-2 px-3">{(report['macro avg'].precision * 100).toFixed(1)}%</td>
                    <td className="py-2 px-3">{(report['macro avg'].recall * 100).toFixed(1)}%</td>
                    <td className="py-2 px-3">{(report['macro avg']['f1-score'] * 100).toFixed(1)}%</td>
                    <td className="py-2 px-3 text-right text-slate-400">{report['macro avg'].support?.toLocaleString()}</td>
                  </tr>
                )}
                {report?.['weighted avg'] && (
                  <tr className="bg-slate-900/50 text-slate-200 font-semibold">
                    <td className="py-2 px-3 font-sans text-cyan-400">Weighted Avg</td>
                    <td className="py-2 px-3">{(report['weighted avg'].precision * 100).toFixed(1)}%</td>
                    <td className="py-2 px-3">{(report['weighted avg'].recall * 100).toFixed(1)}%</td>
                    <td className="py-2 px-3">{(report['weighted avg']['f1-score'] * 100).toFixed(1)}%</td>
                    <td className="py-2 px-3 text-right text-slate-400">{report['weighted avg'].support?.toLocaleString()}</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};
