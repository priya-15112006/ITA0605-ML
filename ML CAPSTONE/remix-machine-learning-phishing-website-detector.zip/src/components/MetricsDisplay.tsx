import React from 'react';
import { Award, Target, CheckCheck, Zap, Activity, Info } from 'lucide-react';
import { ModelInfo } from '../types';

interface Props {
  modelInfo: ModelInfo | null | undefined;
}

export const MetricsDisplay: React.FC<Props> = ({ modelInfo }) => {
  if (!modelInfo || !modelInfo.metrics) {
    return (
      <div className="bg-slate-900/60 border border-slate-800/80 rounded-xl p-8 text-center">
        <div className="w-12 h-12 rounded-xl bg-slate-800 border border-slate-700 mx-auto flex items-center justify-center text-slate-500 mb-3">
          <Award className="w-6 h-6" />
        </div>
        <h3 className="text-base font-semibold text-slate-300 mb-1">
          No Machine Learning Model Trained Yet
        </h3>
        <p className="text-xs text-slate-500 max-w-md mx-auto mb-4">
          Strict policy enforced: mock data, invented numbers, and synthetic results are prohibited.
          Real evaluation metrics will display here immediately upon training on your Supabase dataset.
        </p>
        <div className="inline-flex items-center gap-2 text-xs text-cyan-400 bg-cyan-950/40 border border-cyan-800/50 px-3.5 py-1.5 rounded-lg">
          <Info className="w-4 h-4 shrink-0" />
          Click &ldquo;Train Random Forest Classifier&rdquo; once your database is connected.
        </div>
      </div>
    );
  }

  const { metrics, dataset_summary, durations, trained_at, file_size_mb } = modelInfo;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Award className="w-5 h-5 text-amber-400" />
            Holdout Test Evaluation Metrics (Scikit-learn)
          </h2>
          <p className="text-xs text-slate-400">
            Evaluated on {dataset_summary.testing_samples.toLocaleString()} unseen test URLs ({modelInfo.model_name})
          </p>
        </div>
        <div className="text-xs text-slate-500 font-mono">
          Trained: {new Date(trained_at).toLocaleString()} • Size: {file_size_mb} MB
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
        {/* Accuracy */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1 bg-cyan-500"></div>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider">Accuracy</span>
            <Target className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-white">
            {(metrics.accuracy * 100).toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Overall correct classifications
          </div>
        </div>

        {/* Precision */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1 bg-emerald-500"></div>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider">Precision</span>
            <CheckCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-emerald-400">
            {(metrics.precision * 100).toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            TP / (TP + FP) (Low false alarm)
          </div>
        </div>

        {/* Recall */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1 bg-indigo-500"></div>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider">Recall</span>
            <Zap className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-indigo-300">
            {(metrics.recall * 100).toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            TP / (TP + FN) (Caught threats)
          </div>
        </div>

        {/* F1 Score */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-1 bg-amber-500"></div>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider">F1-Score</span>
            <Award className="w-4 h-4 text-amber-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-amber-300">
            {(metrics.f1_score * 100).toFixed(2)}%
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Harmonic mean of Prec. & Recall
          </div>
        </div>

        {/* ROC AUC */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-4 relative overflow-hidden col-span-2 sm:col-span-1">
          <div className="absolute top-0 left-0 right-0 h-1 bg-purple-500"></div>
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-xs font-semibold uppercase tracking-wider">ROC-AUC</span>
            <Activity className="w-4 h-4 text-purple-400" />
          </div>
          <div className="text-2xl font-bold font-mono text-purple-300">
            {metrics.roc_auc.toFixed(4)}
          </div>
          <div className="text-[11px] text-slate-500 mt-1">
            Discriminative power
          </div>
        </div>
      </div>

      {/* Dataset Breakdown Banner */}
      <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-4 text-xs">
        <div className="flex items-center gap-4 flex-wrap">
          <div>
            <span className="text-slate-500">Valid Ingested: </span>
            <span className="font-mono font-semibold text-slate-200">
              {dataset_summary.total_valid_records.toLocaleString()}
            </span>
          </div>
          <div>
            <span className="text-slate-500">Legitimate: </span>
            <span className="font-mono font-semibold text-emerald-400">
              {dataset_summary.legitimate_count.toLocaleString()}
            </span>
          </div>
          <div>
            <span className="text-slate-500">Phishing: </span>
            <span className="font-mono font-semibold text-rose-400">
              {dataset_summary.phishing_count.toLocaleString()}
            </span>
          </div>
          <div>
            <span className="text-slate-500">Dropped Invalids: </span>
            <span className="font-mono font-semibold text-amber-400">
              {dataset_summary.dropped_invalid_labels.toLocaleString()}
            </span>
          </div>
        </div>

        <div className="text-slate-400 font-mono text-[11px]">
          Ingest: {durations.fetch_seconds}s | Features: {durations.feature_extraction_seconds}s | Fit: {durations.training_seconds}s
        </div>
      </div>
    </div>
  );
};
