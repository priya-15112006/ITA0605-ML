import React, { useState } from 'react';
import { BookOpen, Code2, Terminal, Shield, Database, Cpu, ChevronRight } from 'lucide-react';

export const DocumentationDrawer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'architecture' | 'cli' | 'features' | 'security'>('architecture');

  return (
    <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-5 shadow-lg">
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 mb-4 border-b border-slate-800">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-white">System Architecture & Technical Reference</h3>
            <p className="text-xs text-slate-400">
              Details on Python runtime, Scikit-learn Random Forest, Supabase batch pagination, and CLI commands.
            </p>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800 text-xs">
          <button
            onClick={() => setActiveTab('architecture')}
            className={`px-3 py-1.5 rounded-md font-medium transition ${
              activeTab === 'architecture' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Backend & ML Runtime
          </button>
          <button
            onClick={() => setActiveTab('cli')}
            className={`px-3 py-1.5 rounded-md font-medium transition ${
              activeTab === 'cli' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            CLI Execution Commands
          </button>
          <button
            onClick={() => setActiveTab('features')}
            className={`px-3 py-1.5 rounded-md font-medium transition ${
              activeTab === 'features' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            22 URL Feature Formulas
          </button>
          <button
            onClick={() => setActiveTab('security')}
            className={`px-3 py-1.5 rounded-md font-medium transition ${
              activeTab === 'security' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Security & Supabase Storage
          </button>
        </div>
      </div>

      {activeTab === 'architecture' && (
        <div className="space-y-4 text-xs text-slate-300">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="flex items-center gap-2 font-semibold text-emerald-400 text-sm">
              <Cpu className="w-4 h-4" />
              Verified Native Python 3.10 & Scikit-learn Runtime
            </div>
            <p className="leading-relaxed text-slate-300">
              The application executes in a full Linux container equipped with <strong>Python 3.10.12</strong>,{' '}
              <strong>Scikit-learn 1.7.2</strong>, <strong>NumPy 2.2.6</strong>, <strong>Pandas 2.3.3</strong>,{' '}
              and <strong>Joblib 1.6.0</strong>.
            </p>
            <p className="leading-relaxed text-slate-300">
              <strong>Zero Heuristic Policy:</strong> No JavaScript approximation or synthetic score is used. Every metric (Accuracy, Precision, Recall, F1, Confusion Matrix) is computed directly by Scikit-learn&apos;s evaluation routines on holdout test splits from your actual Supabase dataset.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div className="p-3 rounded-lg bg-slate-950/70 border border-slate-800">
              <div className="font-semibold text-slate-200 mb-1 flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5 text-cyan-400" /> 1. Paginated Ingestion
              </div>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Uses PostgREST <code className="text-cyan-300">.range(start, end)</code> in configurable 1,000-record batches. Safely bypasses the default 1,000-row query ceiling to ingest the full ~340,000 dataset without timeouts.
              </p>
            </div>
            <div className="p-3 rounded-lg bg-slate-950/70 border border-slate-800">
              <div className="font-semibold text-slate-200 mb-1 flex items-center gap-1.5">
                <Code2 className="w-3.5 h-3.5 text-cyan-400" /> 2. Label Normalization
              </div>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Cleans string, numeric, and mixed labels (e.g., &ldquo;phishing&rdquo;, &ldquo;legitimate&rdquo;, &ldquo;1&rdquo;, &ldquo;0&rdquo;). Automatically drops nulls, malformed URLs, and duplicates to protect against data leakage.
              </p>
            </div>
            <div className="p-3 rounded-lg bg-slate-950/70 border border-slate-800">
              <div className="font-semibold text-slate-200 mb-1 flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-cyan-400" /> 3. Random Forest Fit
              </div>
              <p className="text-slate-400 text-[11px] leading-relaxed">
                Trains an ensemble of decision trees with balanced class weighting. Serializes the trained pipeline into <code className="text-cyan-300">ml/saved_models/random_forest_phishing.joblib</code> for persistence.
              </p>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'cli' && (
        <div className="space-y-3 text-xs">
          <p className="text-slate-300">
            You can run the entire pipeline directly from the shell or CI/CD terminal without touching the browser:
          </p>

          <div className="space-y-2 font-mono">
            <div>
              <span className="text-slate-400 text-[11px]"># 1. Quick benchmark run (10,000 records from Supabase):</span>
              <pre className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-cyan-300 overflow-x-auto text-[11px]">
python3 ml/train.py --batch-size 1000 --max-records 10000 --test-size 0.2 --n-estimators 100
              </pre>
            </div>

            <div>
              <span className="text-slate-400 text-[11px]"># 2. Train on the FULL ~340,000 records dataset:</span>
              <pre className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-cyan-300 overflow-x-auto text-[11px]">
python3 ml/train.py --batch-size 2000 --test-size 0.2 --n-estimators 100 --max-depth 25
              </pre>
            </div>

            <div>
              <span className="text-slate-400 text-[11px]"># 3. Test a URL from the command line using the saved joblib model:</span>
              <pre className="p-3 rounded-lg bg-slate-950 border border-slate-800 text-cyan-300 overflow-x-auto text-[11px]">
python3 ml/predict.py "https://update-account-security-banking.xyz/login.php" --json
              </pre>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'features' && (
        <div className="space-y-3 text-xs">
          <p className="text-slate-300">
            The feature extractor calculates 22 lexical, structural, and information-theoretic properties from each raw URL:
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-slate-300">
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
              <span className="font-semibold text-cyan-300">Length & Structural:</span>{' '}
              URL Length, Domain Length, Path Length, Subdomain Count.
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
              <span className="font-semibold text-cyan-300">Delimiters & Symbols:</span>{' '}
              Counts of dots (.), hyphens (-), underscores (_), slashes (/), equals (=), question marks (?).
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
              <span className="font-semibold text-cyan-300">Obfuscation Signals:</span>{' '}
              @ symbol count (credential spoofing), % count (URL encoding), Ampersand (&) count.
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
              <span className="font-semibold text-cyan-300">Character Ratios:</span>{' '}
              Total digit count, digit ratio, total letters.
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
              <span className="font-semibold text-cyan-300">Network & Protocol:</span>{' '}
              HTTPS indicator (0 or 1), Raw IPv4 regex check in hostname (e.g. 192.168.x.x).
            </div>
            <div className="p-2.5 rounded bg-slate-950 border border-slate-800">
              <span className="font-semibold text-cyan-300">Advanced Lexical & Entropy:</span>{' '}
              Phishing keyword list matching, TLD in path/query disguise, Shannon character entropy.
            </div>
          </div>
        </div>
      )}

      {activeTab === 'security' && (
        <div className="space-y-3 text-xs text-slate-300">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-2">
            <div className="font-semibold text-emerald-400 flex items-center gap-2">
              <Shield className="w-4 h-4" /> Server-Side Credentials Protection
            </div>
            <p className="leading-relaxed">
              In accordance with security best practices, the Supabase project URL and service/anon keys are strictly read by the Node.js/Python server process via <code className="text-cyan-300">.env</code>.
            </p>
            <p className="leading-relaxed">
              Neither the Vite bundle nor the client browser receives the database credentials or communicates directly with Supabase. All batch requests originate server-side.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
