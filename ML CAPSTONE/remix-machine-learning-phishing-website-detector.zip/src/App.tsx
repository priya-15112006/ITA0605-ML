import React, { useState, useEffect, useCallback } from 'react';
import {
  ShieldCheck,
  Cpu,
  Database,
  Sliders,
  CheckCircle2,
  AlertCircle,
  ExternalLink,
  Search,
  Activity
} from 'lucide-react';
import { BackendInfo, SupabaseStatus, TrainingJobStatus, ModelInfo } from './types';
import { parseApiResponse } from './utils/api';
import { UrlCheckerMain } from './components/UrlCheckerMain';
import { BackendStatusBadge } from './components/BackendStatusBadge';
import { SupabaseConfigModal } from './components/SupabaseConfigModal';
import { TrainingControlPanel } from './components/TrainingControlPanel';
import { TrainingConsoleLogs } from './components/TrainingConsoleLogs';
import { MetricsDisplay } from './components/MetricsDisplay';
import { ConfusionMatrixCard } from './components/ConfusionMatrixCard';
import { FeatureImportanceChart } from './components/FeatureImportanceChart';
import { DocumentationDrawer } from './components/DocumentationDrawer';

export default function App() {
  // Default to URL checker home page
  const [activeTab, setActiveTab] = useState<'checker' | 'diagnostics'>('checker');

  const [backendInfo, setBackendInfo] = useState<BackendInfo | null>(null);
  const [isCheckingBackend, setIsCheckingBackend] = useState(true);
  const [supabaseStatus, setSupabaseStatus] = useState<SupabaseStatus | null>(null);
  const [isTestingDB, setIsTestingDB] = useState(false);
  const [dbTestMessage, setDbTestMessage] = useState<{ text: string; success: boolean } | null>(null);
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);

  const [jobStatus, setJobStatus] = useState<TrainingJobStatus>({
    status: 'idle',
    logs: [],
    startTime: null,
    endTime: null,
    error: null
  });

  const [modelInfo, setModelInfo] = useState<ModelInfo | null>(null);

  // Fetch backend runtime info & metrics
  const refreshBackendInfo = useCallback(async (): Promise<boolean> => {
    try {
      const res = await fetch('/api/backend-info');
      const data = await parseApiResponse<BackendInfo>(res);
      setBackendInfo(data);
      if (data.modelInfo) {
        setModelInfo(data.modelInfo);
      }
      setIsCheckingBackend(false);
      return true;
    } catch (err) {
      console.error('Failed to fetch backend info:', err);
      return false;
    }
  }, []);

  const refreshMetrics = useCallback(async (): Promise<boolean> => {
    try {
      const res = await fetch('/api/metrics');
      const data = await parseApiResponse<any>(res);
      if (data.trained && data.metrics) {
        setModelInfo(data);
      }
      return true;
    } catch (err) {
      console.error('Failed to fetch metrics:', err);
      return false;
    }
  }, []);

  // Test Supabase connection
  const handleTestDatabase = async () => {
    setIsTestingDB(true);
    setDbTestMessage(null);
    try {
      const res = await fetch('/api/supabase/status');
      const data = await parseApiResponse<SupabaseStatus>(res);
      setSupabaseStatus(data);
      if (data.connected) {
        setDbTestMessage({
          text: `Connected to Supabase table '${data.table}'! Total rows: ${data.total_rows_estimate?.toLocaleString()}`,
          success: true
        });
      } else {
        setDbTestMessage({
          text: data.error || 'Connection failed. Please check your Supabase credentials.',
          success: false
        });
      }
    } catch (err: any) {
      setDbTestMessage({
        text: 'Failed to reach backend API: ' + (err?.message || 'Unknown error'),
        success: false
      });
    } finally {
      setIsTestingDB(false);
    }
  };

  // Launch training job
  const handleStartTraining = async (params: {
    batchSize: number;
    maxRecords?: number;
    testSize: number;
    nEstimators: number;
    maxDepth: number;
  }) => {
    try {
      const res = await fetch('/api/train', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params)
      });
      await parseApiResponse(res);
      setJobStatus(prev => ({
        ...prev,
        status: 'running',
        error: null,
        logs: [
          `[${new Date().toISOString()}] Job started. Running Scikit-learn process on Supabase dataset...`
        ]
      }));
    } catch (err: any) {
      const msg = err?.message || 'Failed to start training pipeline';
      setJobStatus(prev => ({
        ...prev,
        status: 'error',
        error: msg,
        logs: [...prev.logs, `[${new Date().toISOString()}] ERROR: ${msg}`]
      }));
    }
  };

  // Poll training job status when running
  useEffect(() => {
    let interval: ReturnType<typeof setInterval> | null = null;
    if (jobStatus.status === 'running') {
      interval = setInterval(async () => {
        try {
          const res = await fetch('/api/train/status');
          const data = await parseApiResponse<TrainingJobStatus>(res);
          setJobStatus(data);
          if (data.status === 'completed' || data.status === 'error') {
            refreshMetrics();
            refreshBackendInfo();
          }
        } catch (e) {
          console.error('Error polling training status:', e);
        }
      }, 1500);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [jobStatus.status, refreshMetrics, refreshBackendInfo]);

  // Initial load with automatic retry if backend is warming up (e.g., transient 503)
  useEffect(() => {
    let cancelled = false;
    let retryTimer: ReturnType<typeof setTimeout> | null = null;
    let attempts = 0;

    const loadInitial = async () => {
      const [okInfo] = await Promise.all([refreshBackendInfo(), refreshMetrics()]);
      if (!cancelled && !okInfo && attempts < 10) {
        attempts += 1;
        retryTimer = setTimeout(loadInitial, 2000);
      } else if (!cancelled && !okInfo) {
        setIsCheckingBackend(false);
      }
    };

    loadInitial();

    return () => {
      cancelled = true;
      if (retryTimer) clearTimeout(retryTimer);
    };
  }, [refreshBackendInfo, refreshMetrics]);

  const isModelReady = isCheckingBackend ? true : Boolean(backendInfo?.modelTrained || modelInfo);

  return (
    <div className="min-h-screen bg-[#070d1e] text-slate-100 font-sans selection:bg-teal-500 selection:text-black flex flex-col">
      {/* Top Navigation Bar */}
      <header className="border-b border-[#172545] bg-[#0a1228]/90 backdrop-blur-md sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-teal-400 to-teal-600 flex items-center justify-center shadow-lg shadow-teal-500/20 text-slate-950 font-bold">
              <ShieldCheck className="w-6 h-6 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-base sm:text-lg font-black tracking-tight text-white">
                  PhishShield
                </span>
                <span className="text-[10px] uppercase font-mono tracking-wider font-bold px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/30">
                  ML Protected
                </span>
              </div>
              <p className="text-[11px] text-slate-400 hidden sm:block">
                URL Phishing Detection Powered by Random Forest
              </p>
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center gap-2">
            <div className="bg-[#0e1b36] p-1 rounded-xl border border-[#1e2f56] flex items-center gap-1 text-xs font-semibold">
              <button
                onClick={() => setActiveTab('checker')}
                className={`px-3 sm:px-4 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'checker'
                    ? 'bg-teal-500 text-slate-950 font-bold shadow-md shadow-teal-500/20'
                    : 'text-slate-300 hover:text-white hover:bg-[#15274d]'
                }`}
              >
                <Search className="w-3.5 h-3.5" />
                <span>URL Checker</span>
              </button>
              <button
                onClick={() => setActiveTab('diagnostics')}
                className={`px-3 sm:px-4 py-1.5 rounded-lg transition flex items-center gap-1.5 cursor-pointer ${
                  activeTab === 'diagnostics'
                    ? 'bg-teal-500 text-slate-950 font-bold shadow-md shadow-teal-500/20'
                    : 'text-slate-400 hover:text-white hover:bg-[#15274d]'
                }`}
              >
                <Activity className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Model &amp; Benchmarks</span>
                <span className="sm:hidden">Diagnostics</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content View */}
      <main className="flex-1 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 w-full">
        {/* VIEW 1: Clean, User-Friendly URL Checker (Default Home Page) */}
        {activeTab === 'checker' && (
          <UrlCheckerMain modelTrained={isModelReady} />
        )}

        {/* VIEW 2: Secondary Model & Database Diagnostics (Available separately) */}
        {activeTab === 'diagnostics' && (
          <div className="space-y-6 animate-in fade-in duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-[#1e2f56]">
              <div>
                <h2 className="text-xl font-bold text-white flex items-center gap-2">
                  <Activity className="w-5 h-5 text-teal-400" />
                  Model Telemetry, Evaluation &amp; Supabase Integration
                </h2>
                <p className="text-xs text-slate-400 mt-1">
                  Manage database connectivity, execute batch training benchmarks on Supabase, and inspect Scikit-learn test metrics.
                </p>
              </div>
              <button
                onClick={() => setActiveTab('checker')}
                className="text-xs text-teal-400 hover:text-teal-300 font-semibold px-3 py-1.5 rounded-lg bg-[#0e1b36] border border-[#1e2f56] transition"
              >
                &larr; Return to URL Checker
              </button>
            </div>

            {/* Backend Runtime & Supabase Status Header */}
            <BackendStatusBadge
              info={backendInfo}
              onOpenConfig={() => setIsConfigModalOpen(true)}
              onRefresh={handleTestDatabase}
              isTestingConnection={isTestingDB}
            />

            {/* Database Test Result Alert Banner */}
            {dbTestMessage && (
              <div
                className={`p-3.5 rounded-xl text-xs flex items-center justify-between gap-3 border shadow-md ${
                  dbTestMessage.success
                    ? 'bg-emerald-950/40 text-emerald-300 border-emerald-800/50'
                    : 'bg-rose-950/40 text-rose-300 border-rose-800/50'
                }`}
              >
                <div className="flex items-center gap-2">
                  {dbTestMessage.success ? (
                    <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
                  )}
                  <span>{dbTestMessage.text}</span>
                </div>
                <button
                  onClick={() => setDbTestMessage(null)}
                  className="text-slate-400 hover:text-white text-xs px-2 py-0.5"
                >
                  Dismiss
                </button>
              </div>
            )}

            {/* Holdout Test Evaluation Metrics */}
            <MetricsDisplay modelInfo={modelInfo} />

            {/* Confusion Matrix & Detailed Classification Report */}
            <ConfusionMatrixCard modelInfo={modelInfo} />

            {/* 22 Feature Importances Chart */}
            <FeatureImportanceChart modelInfo={modelInfo} />

            {/* Pipeline & Model Control Panel */}
            <TrainingControlPanel
              onStartTraining={handleStartTraining}
              jobStatus={jobStatus}
              supabaseConfigured={backendInfo?.supabaseConfigured ?? false}
            />

            {/* Live Streaming Execution Console */}
            <TrainingConsoleLogs job={jobStatus} />

            {/* Technical Documentation Drawer */}
            <DocumentationDrawer />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#172545] bg-[#091224] py-6 mt-12 text-center text-xs text-slate-500">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-400">PhishShield ML</span>
            <span>&bull;</span>
            <span>Random Forest URL Classifier</span>
          </div>
          <div className="text-[11px] text-slate-500 font-mono">
            Powered by Python 3.10 &bull; Scikit-learn &bull; Supabase PostgREST
          </div>
        </div>
      </footer>

      {/* Modal for setting Supabase credentials */}
      <SupabaseConfigModal
        isOpen={isConfigModalOpen}
        onClose={() => setIsConfigModalOpen(false)}
        onSuccess={() => {
          refreshBackendInfo();
          handleTestDatabase();
        }}
        defaultTable={backendInfo?.supabaseTable || 'phishing_dataset'}
      />
    </div>
  );
}
