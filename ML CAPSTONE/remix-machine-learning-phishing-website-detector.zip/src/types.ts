export interface BackendInfo {
  runtime: string;
  pythonAvailable: boolean;
  scikitLearnVersion: string;
  scikitLearnSupported: boolean;
  mlEngine: string;
  database: string;
  supabaseConfigured: boolean;
  supabaseTable: string;
  modelTrained: boolean;
  modelInfo?: ModelInfo | null;
}

export interface SupabaseStatus {
  connected: boolean;
  table?: string;
  sample_rows?: Array<{ url: string; label: any }>;
  total_rows_estimate?: number | string;
  url_host?: string;
  error?: string;
}

export interface TrainingJobStatus {
  status: 'idle' | 'running' | 'completed' | 'error';
  logs: string[];
  startTime: number | null;
  endTime: number | null;
  error: string | null;
}

export interface ModelInfo {
  status: string;
  model_name: string;
  saved_file: string;
  file_size_mb: number;
  trained_at: string;
  dataset_summary: {
    table: string;
    total_valid_records: number;
    training_samples: number;
    testing_samples: number;
    legitimate_count: number;
    phishing_count: number;
    dropped_invalid_labels: number;
    dropped_missing_urls: number;
    dropped_duplicates: number;
  };
  durations: {
    fetch_seconds: number;
    feature_extraction_seconds: number;
    training_seconds: number;
    total_seconds: number;
  };
  metrics: {
    accuracy: number;
    precision: number;
    recall: number;
    f1_score: number;
    roc_auc: number;
  };
  confusion_matrix: {
    matrix: number[][];
    true_negatives: number;
    false_positives: number;
    false_negatives: number;
    true_positives: number;
  };
  classification_report: Record<string, any>;
  feature_importances: Array<{ feature: string; importance: number }>;
  feature_names: string[];
}

export interface PredictionResult {
  url: string;
  classification: 'Potential Phishing' | 'Likely Legitimate' | 'Phishing' | 'Legitimate';
  is_phishing: boolean;
  phishing_probability: number;
  legitimate_probability: number;
  risk_level: 'Safe' | 'Moderate' | 'High' | 'Critical';
  indicators: string[];
  extracted_features: Record<string, number | string>;
}
