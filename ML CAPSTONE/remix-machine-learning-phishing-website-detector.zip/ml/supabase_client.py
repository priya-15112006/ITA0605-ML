"""
Supabase Database Client & Batch Pagination Manager
Handles secure connection, paginated record retrieval, and label cleaning/normalization.
Communicates directly with the PostgREST /rest/v1 endpoint using valid Range headers.
"""

import os
import re
import sys
import time
from typing import Callable, Dict, List, Optional, Tuple
import httpx

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# Load environment variables from .env if present (with override)
try:
    from dotenv import load_dotenv
    load_dotenv(os.path.join(PROJECT_ROOT, '.env'), override=True)
except ImportError:
    pass


def clean_supabase_url(raw_url: str) -> str:
    """
    Normalizes Supabase URL to the base project URL (e.g. https://<project>.supabase.co).
    Strips accidental trailing slashes and /rest/v1 paths.
    """
    if not raw_url:
        return ''
    url = str(raw_url).strip().rstrip('/')
    if '/rest/v1' in url:
        url = url.split('/rest/v1')[0].rstrip('/')
    return url


def get_supabase_credentials() -> Tuple[str, str, str]:
    """
    Extracts Supabase credentials securely from environment variables.
    Handles key prioritization: favors secret/service-role keys (sb_secret_*) over
    publishable keys (sb_publishable_*) so that Row Level Security (RLS) does not
    block reading the phishing_dataset table. Never exposes keys to client bundles.
    """
    raw_url = os.environ.get('SUPABASE_URL', '').strip()
    url = clean_supabase_url(raw_url)

    # Check all possible key variables
    candidate_keys = []
    for var_name in ['SUPABASE_SERVICE_ROLE_KEY', 'SUPABASE_SECRET_KEY', 'SUPABASE_KEY', 'SUPABASE_ANON_KEY']:
        val = os.environ.get(var_name, '').strip()
        if val and val not in candidate_keys:
            candidate_keys.append(val)

    # Prioritize secret / service-role key
    selected_key = ''
    for k in candidate_keys:
        if k.startswith('sb_secret_') or 'service' in k.lower():
            selected_key = k
            break

    if not selected_key and candidate_keys:
        selected_key = candidate_keys[0]

    table = os.environ.get('SUPABASE_TABLE_NAME', 'phishing_dataset').strip()
    return url, selected_key, table


def get_masked_key(key: str) -> str:
    """Returns a safely masked key representation for logging (e.g. sb_secret_***)."""
    if not key:
        return '(none)'
    if len(key) <= 8:
        return '***'
    prefix = key[:10] if len(key) >= 10 else key[:4]
    suffix = key[-4:]
    return f"{prefix}...{suffix}"


def normalize_label(raw_label) -> Optional[int]:
    """
    Inspects and normalizes raw dataset labels into 0 (Legitimate) or 1 (Phishing).
    Returns None if label is invalid, missing, or unrecognized.
    """
    if raw_label is None:
        return None

    if isinstance(raw_label, (int, float)):
        if raw_label == 0 or raw_label == 0.0:
            return 0
        if raw_label == 1 or raw_label == 1.0:
            return 1
        return None

    s = str(raw_label).strip().lower()
    if not s:
        return None

    # Legitimate aliases
    if s in {'0', '0.0', 'legitimate', 'legit', 'benign', 'good', 'normal', 'safe', 'ham', 'clean'}:
        return 0

    # Phishing aliases
    if s in {'1', '1.0', 'phishing', 'phish', 'malicious', 'bad', 'spam', 'fraud', 'attack'}:
        return 1

    return None


def test_connection() -> Dict:
    """
    Tests connection to Supabase and inspects the phishing_dataset table schema & labels.
    Queries the REST endpoint: /rest/v1/{table}?select=url,label with a small range query.
    Logs HTTP status, response details, and number of rows returned. Never prints secret keys.
    """
    url, key, table = get_supabase_credentials()
    if not url or not key:
        return {
            'connected': False,
            'error': 'Missing SUPABASE_URL or SUPABASE_KEY in environment variables.',
            'configured_table': table
        }

    endpoint = f"{url}/rest/v1/{table}"
    headers = {
        'apikey': key,
        'Authorization': f'Bearer {key}',
        'Range-Unit': 'items',
        'Range': '0-4',
        'Prefer': 'count=exact'
    }

    print(f"[Supabase Test] Target REST Endpoint: {endpoint}", file=sys.stderr, flush=True)
    print(f"[Supabase Test] Using Key: {get_masked_key(key)}", file=sys.stderr, flush=True)

    try:
        with httpx.Client(timeout=15.0, follow_redirects=True) as client:
            resp = client.get(f"{endpoint}?select=url,label", headers=headers)

        status_code = resp.status_code
        content_range = resp.headers.get('content-range', '')
        print(f"[Supabase Test] HTTP Status: {status_code}", file=sys.stderr, flush=True)
        print(f"[Supabase Test] Content-Range Header: '{content_range}'", file=sys.stderr, flush=True)

        if status_code in (200, 206):
            data = resp.json()
            rows_returned = len(data) if isinstance(data, list) else 0
            print(f"[Supabase Test] Rows returned: {rows_returned}", file=sys.stderr, flush=True)

            # Check if total count is available in Content-Range header (e.g. 0-4/340000)
            total_estimate = "Unknown"
            if '/' in content_range:
                total_part = content_range.split('/')[-1].strip()
                if total_part.isdigit():
                    total_estimate = int(total_part)
                elif total_part == '0' or total_part == '*':
                    total_estimate = 0

            # If HTTP 200/206 but 0 rows returned and Content-Range is */0,
            # this indicates Row Level Security (RLS) is blocking the key.
            if rows_returned == 0:
                is_pub = key.startswith('sb_publishable_') or 'publishable' in key
                rls_hint = (
                    "Row Level Security (RLS) is enabled on 'phishing_dataset' and blocking read access "
                    "for this publishable key. Please provide your Supabase Secret / Service Role Key "
                    "(starting with sb_secret_ or service_role), or grant SELECT permission to anon in Supabase."
                    if is_pub else
                    "Database table 'phishing_dataset' returned 0 records. Please verify the table contains data."
                )
                return {
                    'connected': False,
                    'error': rls_hint,
                    'status_code': status_code,
                    'configured_table': table,
                    'url_host': url.split('//')[-1].split('/')[0]
                }

            # Inspect columns of returned sample rows
            first_row = data[0] if data else {}
            has_url = 'url' in first_row
            has_label = 'label' in first_row
            if not has_url or not has_label:
                return {
                    'connected': False,
                    'error': f"Table '{table}' columns mismatch: found {list(first_row.keys())}, expected 'url' and 'label'.",
                    'configured_table': table
                }

            return {
                'connected': True,
                'table': table,
                'status_code': status_code,
                'sample_rows': data[:5],
                'rows_inspected': rows_returned,
                'total_rows_estimate': total_estimate,
                'url_host': url.split('//')[-1].split('/')[0]
            }
        else:
            err_msg = f"Supabase REST query failed with HTTP {status_code}: {resp.text[:300]}"
            print(f"[Supabase Test Error] {err_msg}", file=sys.stderr, flush=True)
            return {
                'connected': False,
                'error': err_msg,
                'status_code': status_code,
                'configured_table': table
            }

    except Exception as e:
        host = url.split('//')[-1].split('/')[0] if '//' in url else url
        err_text = str(e)
        if 'Name or service not known' in err_text or 'nodename nor servname' in err_text or 'Temporary failure in name resolution' in err_text:
            err_str = (
                f"Unable to resolve Supabase host '{host}' ({err_text}). "
                "The Supabase project may be paused, deleted, or the URL may be incorrect. "
                "Update your active Supabase URL and Key in Supabase Settings."
            )
        else:
            err_str = f"Connection error ({host}): {err_text}"
        print(f"[Supabase Test Exception] {err_str}", file=sys.stderr, flush=True)
        return {
            'connected': False,
            'error': err_str,
            'url_host': host,
            'configured_table': table
        }


def fetch_dataset_in_batches(
    batch_size: int = 1000,
    max_records: Optional[int] = None,
    progress_callback: Optional[Callable[[Dict], None]] = None
) -> Tuple[List[str], List[int], Dict]:
    """
    Retrieves the dataset from Supabase using PostgREST HTTP range pagination.
    Endpoint: /rest/v1/{table}?select=url,label with Range: start-end headers.
    Inspects labels, cleans and normalizes records, and returns (urls, labels, stats).
    """
    url, key, table_name = get_supabase_credentials()
    if not url or not key:
        raise ValueError("Missing Supabase URL or credentials in environment variables.")

    endpoint = f"{url}/rest/v1/{table_name}?select=url,label"
    print(f"[Supabase] Starting paginated retrieval from endpoint: {endpoint}", flush=True)
    print(f"[Supabase] Using key: {get_masked_key(key)} | Batch size: {batch_size}", flush=True)

    cleaned_urls: List[str] = []
    cleaned_labels: List[int] = []

    stats = {
        'total_fetched': 0,
        'valid_records': 0,
        'dropped_missing_url': 0,
        'dropped_invalid_label': 0,
        'dropped_duplicates': 0,
        'legitimate_count': 0,
        'phishing_count': 0,
        'batches_processed': 0,
        'start_time': time.time(),
        'end_time': None
    }

    seen_urls = set()
    start_index = 0

    with httpx.Client(timeout=45.0, follow_redirects=True) as http_client:
        while True:
            current_batch_size = batch_size
            if max_records is not None:
                remaining = max_records - stats['valid_records']
                if remaining <= 0:
                    print(f"[Supabase] Reached requested record limit of {max_records:,}. Stopping pagination.", flush=True)
                    break
                if remaining < current_batch_size:
                    current_batch_size = remaining

            end_index = start_index + current_batch_size - 1

            headers = {
                'apikey': key,
                'Authorization': f'Bearer {key}',
                'Range-Unit': 'items',
                'Range': f"{start_index}-{end_index}"
            }
            if stats['batches_processed'] == 0:
                headers['Prefer'] = 'count=exact'

            retries = 3
            batch_data = None
            response_status = None

            while retries > 0:
                try:
                    resp = http_client.get(endpoint, headers=headers)
                    response_status = resp.status_code

                    if response_status in (200, 206):
                        batch_data = resp.json()
                        break
                    elif response_status == 416:
                        # Range Not Satisfiable: reached actual end of table
                        print(f"[Supabase] HTTP 416 Range reached end of table at index {start_index}.", flush=True)
                        batch_data = []
                        break
                    else:
                        retries -= 1
                        print(
                            f"[Supabase Warning] HTTP {response_status} on rows {start_index}..{end_index}: {resp.text[:200]}. "
                            f"Retrying ({retries} left)...",
                            file=sys.stderr,
                            flush=True
                        )
                        time.sleep(2)
                except Exception as ex:
                    retries -= 1
                    print(
                        f"[Supabase Warning] Request error on range {start_index}..{end_index}: {ex}. "
                        f"Retrying ({retries} left)...",
                        file=sys.stderr,
                        flush=True
                    )
                    time.sleep(2)

            if batch_data is None:
                raise RuntimeError(
                    f"Failed to fetch batch rows {start_index}..{end_index} after retries (HTTP {response_status})."
                )

            fetched_count = len(batch_data)
            if fetched_count == 0:
                print(f"[Supabase] Reached end of dataset table at row {start_index}.", flush=True)
                break

            stats['total_fetched'] += fetched_count
            stats['batches_processed'] += 1

            # Process and clean each record in the batch
            for record in batch_data:
                raw_url = record.get('url')
                raw_label = record.get('label')

                if not raw_url or not isinstance(raw_url, str) or not raw_url.strip():
                    stats['dropped_missing_url'] += 1
                    continue

                clean_url = raw_url.strip()
                if clean_url in seen_urls:
                    stats['dropped_duplicates'] += 1
                    continue

                norm_label = normalize_label(raw_label)
                if norm_label is None:
                    stats['dropped_invalid_label'] += 1
                    continue

                seen_urls.add(clean_url)
                cleaned_urls.append(clean_url)
                cleaned_labels.append(norm_label)

                if norm_label == 1:
                    stats['phishing_count'] += 1
                else:
                    stats['legitimate_count'] += 1

                stats['valid_records'] += 1

                if max_records and stats['valid_records'] >= max_records:
                    break

            progress_info = {
                'batch': stats['batches_processed'],
                'start_index': start_index,
                'fetched_in_batch': fetched_count,
                'total_fetched': stats['total_fetched'],
                'valid_records': stats['valid_records'],
                'legitimate_count': stats['legitimate_count'],
                'phishing_count': stats['phishing_count'],
                'dropped_invalid_label': stats['dropped_invalid_label'],
                'dropped_missing_url': stats['dropped_missing_url'],
                'elapsed_seconds': round(time.time() - stats['start_time'], 1)
            }

            if progress_callback:
                progress_callback(progress_info)
            else:
                print(
                    f"[Batch {stats['batches_processed']}] Rows {start_index:,}..{start_index + fetched_count - 1:,} | "
                    f"Valid: {stats['valid_records']:,} (Legit: {stats['legitimate_count']:,}, Phish: {stats['phishing_count']:,}) | "
                    f"Invalid: {stats['dropped_invalid_label']}",
                    flush=True
                )

            start_index += fetched_count
            if fetched_count < current_batch_size:
                print(f"[Supabase] Batch returned {fetched_count} records (< {current_batch_size}). Table end reached.", flush=True)
                break

    stats['end_time'] = time.time()
    stats['total_seconds'] = round(stats['end_time'] - stats['start_time'], 2)

    print(
        f"[Supabase] Batch retrieval complete! Total Valid: {stats['valid_records']:,} | "
        f"Phishing: {stats['phishing_count']:,} | Legitimate: {stats['legitimate_count']:,} in {stats['total_seconds']}s",
        flush=True
    )

    return cleaned_urls, cleaned_labels, stats
