"""
Prediction Inference Module
Loads saved Random Forest joblib model and predicts whether a given URL is Phishing or Legitimate.
"""

import argparse
import json
import os
import sys

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

try:
    import joblib
except ImportError as e:
    sys.stderr.write(f"Missing dependency: {e}. Please ensure 'joblib' is installed via requirements.txt.\n")
    sys.exit(1)

try:
    import numpy as np
except ImportError as e:
    sys.stderr.write(f"Missing dependency: {e}. Please ensure 'numpy' is installed via requirements.txt.\n")
    sys.exit(1)

try:
    import sklearn
except ImportError as e:
    sys.stderr.write(f"Missing dependency: {e}. Please ensure 'scikit-learn' is installed via requirements.txt.\n")
    sys.exit(1)

from ml.feature_extractor import FEATURE_NAMES, extract_features, extract_features_vector


MODEL_PATH = os.path.join(os.path.dirname(__file__), 'saved_models', 'random_forest_phishing.joblib')
PKL_FALLBACK_PATH = os.path.join(os.path.dirname(__file__), 'saved_models', 'random_forest_phishing.pkl')
INFO_PATH = os.path.join(os.path.dirname(__file__), 'saved_models', 'model_info.json')


def resolve_model_path(model_path: str = MODEL_PATH) -> str:
    """Resolves the model artifact path, checking .pkl fallback if default .joblib is absent."""
    if os.path.exists(model_path):
        return model_path
    if model_path == MODEL_PATH and os.path.exists(PKL_FALLBACK_PATH):
        return PKL_FALLBACK_PATH
    return model_path


def load_model(model_path: str = MODEL_PATH):
    """Loads the joblib/pkl Random Forest model artifact."""
    resolved_path = resolve_model_path(model_path)
    if not os.path.exists(resolved_path):
        raise FileNotFoundError(
            f"No trained model found at '{resolved_path}'. "
            "Please train the model first using the training pipeline."
        )
    data = joblib.load(resolved_path)
    if isinstance(data, dict) and 'model' in data:
        return data['model']
    return data


def predict_url(url: str, model_path: str = MODEL_PATH):
    """
    Predicts whether a URL is phishing or legitimate using the trained Random Forest classifier.
    Returns prediction dictionary with probabilities, classification, and feature breakdown.
    """
    model = load_model(model_path)

    features_dict = extract_features(url)
    features_vec = [float(features_dict[name]) for name in FEATURE_NAMES]
    X = np.array([features_vec], dtype=np.float32)

    # Predict class & probabilities
    pred_label = int(model.predict(X)[0])
    probas = model.predict_proba(X)[0]
    classes = [int(c) for c in getattr(model, 'classes_', [0, 1])]

    if 0 in classes and 1 in classes:
        legit_prob = round(float(probas[classes.index(0)]), 4)
        phish_prob = round(float(probas[classes.index(1)]), 4)
    elif 1 in classes:
        phish_prob = round(float(probas[classes.index(1)]), 4)
        legit_prob = round(1.0 - phish_prob, 4)
    else:
        legit_prob = round(float(probas[0]), 4)
        phish_prob = round(1.0 - legit_prob, 4)

    classification = "Potential Phishing" if pred_label == 1 else "Likely Legitimate"

    risk_level = "Critical" if phish_prob >= 0.85 else (
        "High" if phish_prob >= 0.65 else (
            "Moderate" if phish_prob >= 0.40 else "Safe"
        )
    )

    # Identify top suspicious indicators
    indicators = []
    if features_dict.get('has_ip_address') == 1:
        indicators.append("Host uses raw IP address instead of domain name")
    if features_dict.get('has_suspicious_keywords') == 1:
        indicators.append("Contains targeted phishing keywords (e.g. login, verify, banking)")
    if features_dict.get('is_https') == 0:
        indicators.append("Unencrypted connection (HTTP instead of HTTPS)")
    if features_dict.get('count_dots', 0) > 3:
        indicators.append(f"Abnormally high dot count ({features_dict['count_dots']})")
    if features_dict.get('count_at', 0) > 0:
        indicators.append("Contains '@' symbol (often used for credential URL spoofing)")
    if features_dict.get('tld_in_path') == 1:
        indicators.append("Top-level domain embedded inside URL path or query string")
    if features_dict.get('is_shortener') == 1:
        indicators.append("URL shortener service hides destination domain")
    if features_dict.get('entropy', 0) > 4.5:
        indicators.append(f"High character entropy ({features_dict['entropy']}), indicating randomized or obfuscated URL")
    if features_dict.get('count_subdomains', 0) >= 3:
        indicators.append(f"Multiple subdomains ({features_dict['count_subdomains']})")

    return {
        'url': url,
        'classification': classification,
        'is_phishing': bool(pred_label == 1),
        'phishing_probability': phish_prob,
        'legitimate_probability': legit_prob,
        'risk_level': risk_level,
        'indicators': indicators,
        'extracted_features': features_dict
    }


def main():
    parser = argparse.ArgumentParser(description="Predict if a URL is phishing or legitimate")
    parser.add_argument('url', type=str, help="URL to classify")
    parser.add_argument('--model-path', type=str, default=MODEL_PATH, help="Path to saved model")
    parser.add_argument('--json', action='store_true', help="Output result as JSON")

    args = parser.parse_args()

    try:
        result = predict_url(args.url, args.model_path)
        if args.json:
            print(json.dumps(result, indent=2))
        else:
            print(f"URL: {result['url']}")
            print(f"Classification: {result['classification']} (Risk: {result['risk_level']})")
            print(f"Phishing Probability: {result['phishing_probability'] * 100:.1f}%")
            print(f"Legitimate Probability: {result['legitimate_probability'] * 100:.1f}%")
            if result['indicators']:
                print("\nFlagged Indicators:")
                for ind in result['indicators']:
                    print(f"  - {ind}")
    except Exception as e:
        print(f"Prediction Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
