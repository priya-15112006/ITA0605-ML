"""
Feature Extractor for URL-based Phishing Detection
Extracts structural, lexical, statistical, and domain features from URLs.
"""

import math
import re
from typing import Any, Dict, List
from urllib.parse import urlparse

# Regular expressions
IPV4_REGEX = re.compile(
    r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
)

SUSPICIOUS_KEYWORDS = [
    'login', 'signin', 'sign-in', 'log-in', 'verify', 'verification',
    'authenticate', 'secure', 'security', 'banking', 'bank', 'account',
    'update', 'confirm', 'confirmation', 'wallet', 'paypal', 'appleid',
    'billing', 'payment', 'support', 'service', 'recover', 'password',
    'credential', 'validate', 'webscr', 'alert', 'notice', 'tax', 'irs'
]

COMMON_TLDS_FOR_PATH_CHECK = [
    '.com', '.org', '.net', '.edu', '.gov', '.mil', '.info', '.biz',
    '.xyz', '.top', '.online', '.site', '.club', '.vip', '.work'
]

SHORTENING_DOMAINS = {
    'bit.ly', 'tinyurl.com', 'goo.gl', 't.co', 'ow.ly', 'is.gd',
    'buff.ly', 'adf.ly', 'bit.do', 'cutt.ly', 'tiny.cc', 'rebrand.ly',
    'shorte.st', 'soo.gd', 's.id', 'v.gd', 'tr.im', 'rb.gy'
}

FEATURE_NAMES = [
    'url_length',
    'domain_length',
    'path_length',
    'count_dots',
    'count_hyphens',
    'count_underscores',
    'count_slashes',
    'count_question_marks',
    'count_equals',
    'count_at',
    'count_ampersand',
    'count_percent',
    'count_digits',
    'digit_ratio',
    'count_letters',
    'is_https',
    'has_ip_address',
    'count_subdomains',
    'has_suspicious_keywords',
    'tld_in_path',
    'is_shortener',
    'entropy'
]


def calculate_entropy(text: str) -> float:
    """Calculate Shannon entropy of a string."""
    if not text:
        return 0.0
    freq: Dict[str, int] = {}
    for char in text:
        freq[char] = freq.get(char, 0) + 1
    length = len(text)
    entropy = 0.0
    for count in freq.values():
        p = count / length
        entropy -= p * math.log2(p)
    return round(entropy, 4)


def extract_features(raw_url: str) -> Dict[str, Any]:
    """
    Extracts all 22 structural and lexical features from a URL string.
    Returns a dictionary of feature name -> numerical value.
    """
    url = str(raw_url).strip() if raw_url is not None else ''

    # Handle URLs without scheme for robust parsing
    parsed_input = url
    if not (url.startswith('http://') or url.startswith('https://') or url.startswith('ftp://')):
        parsed_input = 'http://' + url

    try:
        parsed = urlparse(parsed_input)
        domain = parsed.netloc.lower().split(':')[0]
        path = parsed.path
        query = parsed.query
    except Exception:
        domain = ''
        path = ''
        query = ''

    url_len = len(url)
    dom_len = len(domain)
    path_len = len(path)

    # Counts
    dots = url.count('.')
    hyphens = url.count('-')
    underscores = url.count('_')
    slashes = url.count('/')
    question_marks = url.count('?')
    equals = url.count('=')
    ats = url.count('@')
    ampersands = url.count('&')
    percents = url.count('%')

    # Character classes
    digits = sum(1 for c in url if c.isdigit())
    letters = sum(1 for c in url if c.isalpha())
    digit_ratio = (digits / url_len) if url_len > 0 else 0.0

    # Scheme
    is_https = 1 if url.lower().startswith('https://') else 0

    # IP address in domain
    has_ip = 1 if (domain and IPV4_REGEX.match(domain)) else 0

    # Subdomains count (e.g. login.bank.example.com -> 2 subdomains)
    if domain:
        dom_parts = domain.split('.')
        subdomain_count = max(0, len(dom_parts) - 2)
    else:
        subdomain_count = 0

    # Suspicious keywords in URL
    url_lower = url.lower()
    has_keywords = 1 if any(kw in url_lower for kw in SUSPICIOUS_KEYWORDS) else 0

    # TLD in path (deceptive technique e.g. legitimate.com.phishingsite.net/paypal.com/login)
    path_query = (path + '?' + query).lower()
    tld_in_p = 1 if any(tld in path_query for tld in COMMON_TLDS_FOR_PATH_CHECK) else 0

    # Known shortener
    is_short = 1 if (domain in SHORTENING_DOMAINS) else 0

    # Entropy
    entropy = calculate_entropy(url)

    return {
        'url_length': url_len,
        'domain_length': dom_len,
        'path_length': path_len,
        'count_dots': dots,
        'count_hyphens': hyphens,
        'count_underscores': underscores,
        'count_slashes': slashes,
        'count_question_marks': question_marks,
        'count_equals': equals,
        'count_at': ats,
        'count_ampersand': ampersands,
        'count_percent': percents,
        'count_digits': digits,
        'digit_ratio': round(digit_ratio, 4),
        'count_letters': letters,
        'is_https': is_https,
        'has_ip_address': has_ip,
        'count_subdomains': subdomain_count,
        'has_suspicious_keywords': has_keywords,
        'tld_in_path': tld_in_p,
        'is_shortener': is_short,
        'entropy': entropy
    }


def extract_features_vector(url: str) -> List[float]:
    """Extract features as an ordered list of floats matching FEATURE_NAMES."""
    feat_dict = extract_features(url)
    return [float(feat_dict[k]) for k in FEATURE_NAMES]
