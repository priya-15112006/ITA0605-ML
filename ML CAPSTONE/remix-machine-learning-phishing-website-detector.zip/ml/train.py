"""
Machine Learning Training Pipeline
Trains a Scikit-learn Random Forest Classifier on real URL dataset retrieved from Supabase.
Computes real performance metrics: Accuracy, Precision, Recall, F1-Score, and Confusion Matrix.
Saves model to joblib file.
"""

import argparse
import datetime
import json
import os
import sys
import time

# Ensure project root is in sys.path
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score
)
from sklearn.model_selection import train_test_split

from ml.feature_extractor import FEATURE_NAMES, extract_features_vector
from ml.supabase_client import fetch_dataset_in_batches, get_supabase_credentials


DEFAULT_SAVE_DIR = os.path.join(os.path.dirname(__file__), 'saved_models')


def run_training(
    batch_size: int = 1000,
    max_records: int = None,
    test_size: float = 0.2,
    n_estimators: int = 100,
    max_depth: int = 25,
    random_state: int = 42,
    save_dir: str = DEFAULT_SAVE_DIR
):
    print("=" * 70, flush=True)
    print(" MACHINE LEARNING-BASED PHISHING WEBSITE DETECTION USING URL FEATURES", flush=True)
    print("=" * 70, flush=True)

    os.makedirs(save_dir, exist_ok=True)
    model_save_path = os.path.join(save_dir, 'random_forest_phishing.joblib')
    info_save_path = os.path.join(save_dir, 'model_info.json')

    url, key, table = get_supabase_credentials()
    print(f"[*] Supabase Host Target: {url.split('//')[-1].split('/')[0] if '//' in url else url}", flush=True)
    print(f"[*] Target Database Table: '{table}'", flush=True)
    print(f"[*] Hyperparameters: n_estimators={n_estimators}, max_depth={max_depth}, test_size={test_size}", flush=True)

    # 1. Fetch data from Supabase in batches
    fetch_start = time.time()
    urls, labels, fetch_stats = fetch_dataset_in_batches(
        batch_size=batch_size,
        max_records=max_records
    )
    fetch_duration = round(time.time() - fetch_start, 2)

    total_valid = len(urls)
    if total_valid < 10:
        raise ValueError(
            f"Insufficient valid dataset records found ({total_valid} records). "
            f"Ensure the Supabase '{table}' table contains real URL and label data."
        )

    print(f"\n[+] Dataset Ingestion Summary:", flush=True)
    print(f"    - Total Valid Records: {total_valid:,}", flush=True)
    print(f"    - Legitimate (0): {fetch_stats['legitimate_count']:,} ({fetch_stats['legitimate_count']/total_valid*100:.1f}%)", flush=True)
    print(f"    - Phishing (1):   {fetch_stats['phishing_count']:,} ({fetch_stats['phishing_count']/total_valid*100:.1f}%)", flush=True)
    print(f"    - Dropped Invalid Labels: {fetch_stats['dropped_invalid_label']:,}", flush=True)
    print(f"    - Dropped Missing URLs:   {fetch_stats['dropped_missing_url']:,}", flush=True)
    print(f"    - Dropped Duplicate URLs: {fetch_stats['dropped_duplicates']:,}", flush=True)

    # 2. Extract URL Features
    print(f"\n[*] Extracting {len(FEATURE_NAMES)} lexical and structural URL features...", flush=True)
    feat_start = time.time()
    X_list = []
    for i, raw_url in enumerate(urls):
        X_list.append(extract_features_vector(raw_url))
        if (i + 1) % 10000 == 0 or (i + 1) == total_valid:
            print(f"    [Features] Extracted {i + 1:,}/{total_valid:,} URLs ({(i+1)/total_valid*100:.1f}%)", flush=True)

    X = np.array(X_list, dtype=np.float32)
    y = np.array(labels, dtype=np.int32)
    feat_duration = round(time.time() - feat_start, 2)
    print(f"[+] Feature matrix shape: {X.shape} extracted in {feat_duration}s", flush=True)

    # Check class distribution for stratification
    classes, class_counts = np.unique(y, return_counts=True)
    can_stratify = len(classes) > 1 and all(c >= 2 for c in class_counts)

    # 3. Train-Test Split
    print(f"\n[*] Splitting dataset: {int((1-test_size)*100)}% Train / {int(test_size*100)}% Test (stratify={can_stratify})...", flush=True)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y,
        test_size=test_size,
        random_state=random_state,
        stratify=y if can_stratify else None
    )
    print(f"    - Training Set:   {X_train.shape[0]:,} samples", flush=True)
    print(f"    - Testing Set:    {X_test.shape[0]:,} samples", flush=True)

    # 4. Train Random Forest Classifier
    print(f"\n[*] Training Random Forest Classifier ({n_estimators} trees, max_depth={max_depth})...", flush=True)
    train_start = time.time()
    clf = RandomForestClassifier(
        n_estimators=n_estimators,
        max_depth=max_depth,
        random_state=random_state,
        n_jobs=-1,
        class_weight='balanced'
    )
    clf.fit(X_train, y_train)
    train_duration = round(time.time() - train_start, 2)
    print(f"[+] Training completed in {train_duration}s", flush=True)

    # 5. Evaluate on Holdout Test Set
    print(f"\n[*] Evaluating model on unseen holdout test set ({X_test.shape[0]:,} samples)...", flush=True)
    y_pred = clf.predict(X_test)
    y_proba = clf.predict_proba(X_test)[:, 1] if len(classes) > 1 else np.zeros(len(y_test))

    accuracy = float(accuracy_score(y_test, y_pred))
    precision = float(precision_score(y_test, y_pred, zero_division=0))
    recall = float(recall_score(y_test, y_pred, zero_division=0))
    f1 = float(f1_score(y_test, y_pred, zero_division=0))
    try:
        if len(np.unique(y_test)) > 1 and len(classes) > 1:
            raw_roc = float(roc_auc_score(y_test, y_proba))
            roc_auc = 0.5 if np.isnan(raw_roc) else raw_roc
        else:
            roc_auc = 0.5
    except Exception:
        roc_auc = 0.5

    cm = confusion_matrix(y_test, y_pred, labels=[0, 1]).tolist()
    tn, fp = cm[0][0], cm[0][1]
    fn, tp = cm[1][0], cm[1][1]

    clf_report = classification_report(y_test, y_pred, output_dict=True, zero_division=0)

    # Feature Importances
    importances = clf.feature_importances_
    feature_ranking = [
        {'feature': name, 'importance': round(float(imp), 4)}
        for name, imp in sorted(zip(FEATURE_NAMES, importances), key=lambda x: x[1], reverse=True)
    ]

    print("\n" + "=" * 50, flush=True)
    print(" ACTUAL EVALUATION RESULTS ON REAL TEST SET", flush=True)
    print("=" * 50, flush=True)
    print(f" Accuracy:  {accuracy * 100:.2f}%", flush=True)
    print(f" Precision: {precision * 100:.2f}%", flush=True)
    print(f" Recall:    {recall * 100:.2f}%", flush=True)
    print(f" F1-Score:  {f1 * 100:.2f}%", flush=True)
    print(f" ROC-AUC:   {roc_auc:.4f}", flush=True)
    print("-" * 50, flush=True)
    print(f" Confusion Matrix:", flush=True)
    print(f"   [True Legitimate (TN): {tn:,}  |  False Phishing (FP): {fp:,}]", flush=True)
    print(f"   [False Legitimate (FN): {fn:,}  |  True Phishing (TP): {tp:,}]", flush=True)
    print("=" * 50, flush=True)

    # 6. Save Model to Joblib & Info to JSON
    print(f"\n[*] Saving trained model to '{model_save_path}'...", flush=True)
    model_payload = {
        'model': clf,
        'feature_names': FEATURE_NAMES,
        'trained_at': datetime.datetime.utcnow().isoformat() + 'Z',
        'hyperparameters': {
            'n_estimators': n_estimators,
            'max_depth': max_depth,
            'random_state': random_state,
            'test_size': test_size
        }
    }
    joblib.dump(model_payload, model_save_path)
    # Verify serialized artifact reloads cleanly
    loaded_check = joblib.load(model_save_path)
    if not isinstance(loaded_check, dict) or 'model' not in loaded_check:
        raise RuntimeError("Saved model verification check failed.")
    file_size_mb = round(os.path.getsize(model_save_path) / (1024 * 1024), 2)
    print(f"[+] Model file saved and verified successfully ({file_size_mb} MB)", flush=True)

    rel_saved_file = os.path.relpath(model_save_path, PROJECT_ROOT)
    model_info = {
        'status': 'completed',
        'model_name': 'RandomForestClassifier',
        'saved_file': rel_saved_file,
        'file_size_mb': file_size_mb,
        'trained_at': datetime.datetime.utcnow().isoformat() + 'Z',
        'dataset_summary': {
            'table': table,
            'total_valid_records': total_valid,
            'training_samples': int(X_train.shape[0]),
            'testing_samples': int(X_test.shape[0]),
            'legitimate_count': int(fetch_stats['legitimate_count']),
            'phishing_count': int(fetch_stats['phishing_count']),
            'dropped_invalid_labels': int(fetch_stats['dropped_invalid_label']),
            'dropped_missing_urls': int(fetch_stats['dropped_missing_url']),
            'dropped_duplicates': int(fetch_stats['dropped_duplicates']),
        },
        'durations': {
            'fetch_seconds': fetch_duration,
            'feature_extraction_seconds': feat_duration,
            'training_seconds': train_duration,
            'total_seconds': round(fetch_duration + feat_duration + train_duration, 2)
        },
        'metrics': {
            'accuracy': round(accuracy, 4),
            'precision': round(precision, 4),
            'recall': round(recall, 4),
            'f1_score': round(f1, 4),
            'roc_auc': round(roc_auc, 4)
        },
        'confusion_matrix': {
            'matrix': cm,
            'true_negatives': int(tn),
            'false_positives': int(fp),
            'false_negatives': int(fn),
            'true_positives': int(tp)
        },
        'classification_report': clf_report,
        'feature_importances': feature_ranking,
        'feature_names': FEATURE_NAMES
    }

    with open(info_save_path, 'w') as f:
        json.dump(model_info, f, indent=2)
    print(f"[+] Model metadata and evaluation results saved to '{info_save_path}'", flush=True)

    return model_info


def main():
    parser = argparse.ArgumentParser(description="Train Random Forest Phishing Detector on Supabase dataset")
    parser.add_argument('--batch-size', type=int, default=1000, help="Batch size for Supabase pagination")
    parser.add_argument('--max-records', type=int, default=None, help="Maximum records to process (default: all)")
    parser.add_argument('--test-size', type=float, default=0.2, help="Holdout test split ratio (e.g. 0.2)")
    parser.add_argument('--n-estimators', type=int, default=100, help="Number of trees in Random Forest")
    parser.add_argument('--max-depth', type=int, default=25, help="Maximum tree depth")
    parser.add_argument('--save-dir', type=str, default=DEFAULT_SAVE_DIR, help="Directory to save model files")

    args = parser.parse_args()

    try:
        run_training(
            batch_size=args.batch_size,
            max_records=args.max_records,
            test_size=args.test_size,
            n_estimators=args.n_estimators,
            max_depth=args.max_depth,
            save_dir=args.save_dir
        )
    except Exception as e:
        print(f"\n[!] Training Pipeline Error: {e}", file=sys.stderr, flush=True)
        sys.exit(1)


if __name__ == '__main__':
    main()
