#!/usr/bin/env bash
set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"
cd "$PROJECT_ROOT"

echo "[Setup ML] Checking Python ML environment..."

PYTHON_BIN="python3"
if [ -x "$PROJECT_ROOT/.venv/bin/python3" ]; then
    PYTHON_BIN="$PROJECT_ROOT/.venv/bin/python3"
fi

# Quick check if required libraries can already be imported and model loads (if present)
if "$PYTHON_BIN" -c "
import os, joblib, sklearn, numpy, pandas, supabase, httpx
mp = 'ml/saved_models/random_forest_phishing.joblib'
if os.path.exists(mp):
    joblib.load(mp)
" 2>/dev/null; then
    echo "[Setup ML] All Python dependencies are present and Random Forest model loads successfully ($PYTHON_BIN)."
    exit 0
fi

echo "[Setup ML] Python dependencies missing or model verification needed. Configuring environment..."

# Ensure pip is available
if ! "$PYTHON_BIN" -m pip --version &> /dev/null; then
    echo "[Setup ML] pip not found. Bootstrapping pip..."
    if "$PYTHON_BIN" -m ensurepip --upgrade 2>/dev/null; then
        echo "[Setup ML] Bootstrapped pip via ensurepip."
    else
        curl -sS https://bootstrap.pypa.io/get-pip.py -o /tmp/get-pip.py
        "$PYTHON_BIN" /tmp/get-pip.py --break-system-packages --no-warn-script-location 2>/dev/null \
            || "$PYTHON_BIN" /tmp/get-pip.py --user --no-warn-script-location
        rm -f /tmp/get-pip.py
    fi
fi

# Only configure /etc/pip.conf if running with write permission to /etc
if [ -w /etc ] && { [ ! -f /etc/pip.conf ] || ! grep -q "break-system-packages" /etc/pip.conf; }; then
    printf "[global]\nbreak-system-packages = true\n" > /etc/pip.conf || true
fi

install_requirements() {
    local py="$1"
    if [ -f "$PROJECT_ROOT/requirements.txt" ]; then
        "$py" -m pip install --no-cache-dir -r "$PROJECT_ROOT/requirements.txt"
    else
        "$py" -m pip install --no-cache-dir "joblib>=1.3.0" "scikit-learn==1.7.2" "numpy>=1.24.0" "pandas>=2.0.0" "scipy>=1.10.0" "httpx>=0.25.0" "python-dotenv>=1.0.0" "supabase>=2.0.0"
    fi
}

echo "[Setup ML] Installing dependencies from requirements.txt..."
if PIP_BREAK_SYSTEM_PACKAGES=1 install_requirements "$PYTHON_BIN"; then
    echo "[Setup ML] Installed Python dependencies into system environment."
elif PIP_BREAK_SYSTEM_PACKAGES=1 "$PYTHON_BIN" -m pip install --user --no-cache-dir -r "$PROJECT_ROOT/requirements.txt"; then
    echo "[Setup ML] Installed Python dependencies into user environment."
else
    echo "[Setup ML] Falling back to project-local virtualenv (.venv)..."
    "$PYTHON_BIN" -m venv "$PROJECT_ROOT/.venv"
    PYTHON_BIN="$PROJECT_ROOT/.venv/bin/python3"
    install_requirements "$PYTHON_BIN"
fi

# Confirm that the Random Forest model artifact can be loaded (if present)
echo "[Setup ML] Verifying ML imports and Random Forest model artifact..."
"$PYTHON_BIN" -c "
import os, joblib, sklearn, numpy, pandas, supabase
model_path = 'ml/saved_models/random_forest_phishing.joblib'
if os.path.exists(model_path):
    artifact = joblib.load(model_path)
    model = artifact['model'] if isinstance(artifact, dict) and 'model' in artifact else artifact
    print(f'[Setup ML] Successfully loaded model artifact: {type(model).__name__}')
print(f'[Setup ML] scikit-learn version: {sklearn.__version__} | joblib version: {joblib.__version__}')
"

echo "[Setup ML] Environment setup complete."
